#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# widget.py – Chat-Widget Provider für skin.helper / plugin-Aufruf
# Wird aufgerufen via: plugin://script.kodi.chat/?mode=widget

import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib.request
import urllib.parse
import json

API_URL = 'https://rolling-playforfun.dynv6.net/kodi/index.php'
ADDON   = xbmcaddon.Addon()
HANDLE  = int(sys.argv[1]) if len(sys.argv) > 1 else -1


def fetch_messages(limit=10):
    try:
        req = urllib.request.Request(
            API_URL + '?action=read',
            headers={'User-Agent': 'KodiChat/1.4'}
        )
        with urllib.request.urlopen(req, timeout=6) as r:
            msgs = json.loads(r.read().decode('utf-8'))
            return msgs[:limit] if msgs else []
    except Exception as e:
        xbmc.log(f'[KodiChat Widget] fetch error: {e}', xbmc.LOGERROR)
        return []


def run_widget():
    msgs = fetch_messages(10)

    if not msgs:
        item = xbmcgui.ListItem(label='Keine Nachrichten')
        item.setArt({'icon': ADDON.getAddonInfo('icon')})
        xbmcplugin.addDirectoryItem(HANDLE, '', item, False)
    else:
        for m in msgs:
            name = m.get('name', '?')
            text = m.get('message', '')
            time = m.get('time', '')

            # Label = Name: Nachricht  |  Label2 = Uhrzeit
            item = xbmcgui.ListItem(
                label  = f'{name}:  {text}',
                label2 = time
            )
            item.setArt({'icon': ADDON.getAddonInfo('icon')})

            # Info damit der Skin mehr Daten hat
            item.setInfo('video', {
                'title':   f'{name}: {text}',
                'plot':    text,
                'studio':  name,
                'date':    time,
            })

            # Klick → Chat-Addon öffnen
            item.setProperty('IsPlayable', 'false')
            url = 'plugin://script.kodi.chat/?mode=open'
            xbmcplugin.addDirectoryItem(HANDLE, url, item, False)

    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


if __name__ == '__main__':
    run_widget()
