#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# script.kodi.chat v1.4.5 – PlayForFun
#
# Vollbild-Chat – rein Python-basiert, keine XML
# FireTV/Android-Fix: OK-Taste (action 7 + remote-select 18) löst Buttons aus

import xbmc
import xbmcgui
import xbmcaddon
import urllib.request
import urllib.error
import json
import time
import threading

API_URL    = 'https://rolling-playforfun.dynv6.net/kodi/index.php'
ADDON      = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')

POLL_INTERVAL = 10
import os
WHITE_PNG  = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'skins', 'default', 'media', 'white.png')
TRANSP_PNG = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'skins', 'default', 'media', 'transparent.png')

# Action-IDs
ACTION_SELECT          = 7    # OK / Enter (Kodi standard)
ACTION_REMOTE_SELECT   = 18   # FireTV Remote "Select"
ACTION_MOUSE_LEFT      = 100
ACTION_TOUCH_TAP       = 401
ACTION_BACK            = 10
ACTION_PREVIOUS_MENU   = 92


# ─── API ─────────────────────────────────────────────────────────────────────
def api_get():
    try:
        req = urllib.request.Request(
            API_URL + '?action=read',
            headers={'User-Agent': 'KodiChat/1.4'}
        )
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read().decode('utf-8'))
    except Exception as e:
        xbmc.log(f'[KodiChat] GET error: {e}', xbmc.LOGERROR)
        return None

def api_post(name, message, password):
    payload = json.dumps({'name': name, 'message': message, 'password': password}).encode()
    req = urllib.request.Request(
        API_URL + '?action=post', data=payload,
        headers={'Content-Type': 'application/json', 'User-Agent': 'KodiChat/1.4'},
        method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:    return json.loads(e.read().decode('utf-8'))
        except: return {'error': f'HTTP {e.code}'}
    except Exception as e:
        return {'error': str(e)}


# ─── Vollbild-Fenster ─────────────────────────────────────────────────────────
class ChatWindow(xbmcgui.Window):

    def __init__(self, chat_name):
        xbmcgui.Window.__init__(self)
        self.name        = chat_name
        self.pw          = ''
        self.auth        = False
        self._msgs       = []
        self._last_count = 0
        self._lock       = threading.Lock()
        self._stop       = threading.Event()
        self._changed    = False

        self.SW = self.getWidth()
        self.SH = self.getHeight()
        xbmc.log(f'[KodiChat] Screen: {self.SW}x{self.SH}', xbmc.LOGINFO)

        self._build_ui()

    # ── UI aufbauen ──────────────────────────────────────────────────────
    def _build_ui(self):
        W, H = self.SW, self.SH
        pad  = int(W * 0.01)

        # Hintergrund
        self.bg = xbmcgui.ControlImage(0, 0, W, H, WHITE_PNG)
        self.bg.setColorDiffuse('0xFF0a0a18')
        self.addControl(self.bg)

        # Titelleiste
        title_h = int(H * 0.08)
        self.title_bg = xbmcgui.ControlImage(0, 0, W, title_h, WHITE_PNG)
        self.title_bg.setColorDiffuse('0xEE003a5c')
        self.addControl(self.title_bg)

        self.lbl_title = xbmcgui.ControlLabel(
            pad, int(title_h * 0.2), int(W * 0.5), title_h,
            'KODI CHAT – PlayForFun',
            font='font16', textColor='0xFF00d4ff'
        )
        self.addControl(self.lbl_title)

        self.lbl_status = xbmcgui.ControlLabel(
            int(W * 0.42), int(title_h * 0.2), int(W * 0.4), title_h,
            '', font='font16', textColor='0xFF00ff88'
        )
        self.addControl(self.lbl_status)

        # Trennlinie oben
        sep_y = title_h
        self.sep1 = xbmcgui.ControlImage(0, sep_y, W, 2, WHITE_PNG)
        self.sep1.setColorDiffuse('0xFF1a3a5c')
        self.addControl(self.sep1)

        # Nachrichten-Liste
        list_top = sep_y + 2
        btn_h    = int(H * 0.09)
        sep2_y   = H - btn_h - 4
        list_h   = sep2_y - list_top - 2

        self.msg_list = xbmcgui.ControlList(
            pad, list_top, W - pad*2, list_h,
            font='font13',
            textColor='0xFFffffff',
            selectedColor='0xFF00d4ff'
        )
        self.addControl(self.msg_list)

        # Trennlinie über Buttons
        self.sep2 = xbmcgui.ControlImage(0, sep2_y, W, 2, WHITE_PNG)
        self.sep2.setColorDiffuse('0xFF1a3a5c')
        self.addControl(self.sep2)

        # ── Buttons (nur noch: SCHREIBEN  |  SCHLIESSEN)
        btn_top = sep2_y + 4
        btn_w   = int(W * 0.22)
        gap     = int(W * 0.02)

        # Hintergründe
        self.btn_write_bg = xbmcgui.ControlImage(
            pad, btn_top, btn_w, btn_h - 4, WHITE_PNG)
        self.btn_write_bg.setColorDiffuse('0xFF006688')
        self.addControl(self.btn_write_bg)

        self.btn_close_bg = xbmcgui.ControlImage(
            pad + btn_w + gap, btn_top, btn_w, btn_h - 4, WHITE_PNG)
        self.btn_close_bg.setColorDiffuse('0xFF660018')
        self.addControl(self.btn_close_bg)

        # Buttons
        self.btn_write = xbmcgui.ControlButton(
            pad, btn_top, btn_w, btn_h - 4,
            '✏  SCHREIBEN', font='font13',
            textColor='0xFFffffff', focusedColor='0xFF000000',
            focusTexture=TRANSP_PNG, noFocusTexture=TRANSP_PNG
        )
        self.addControl(self.btn_write)

        self.btn_close = xbmcgui.ControlButton(
            pad + btn_w + gap, btn_top, btn_w, btn_h - 4,
            '✖  SCHLIESSEN', font='font13',
            textColor='0xFFffffff', focusedColor='0xFFffffff',
            focusTexture=TRANSP_PNG, noFocusTexture=TRANSP_PNG
        )
        self.addControl(self.btn_close)

        # Hinweis: Zurück-Taste
        self.lbl_hint = xbmcgui.ControlLabel(
            pad + (btn_w + gap)*2, btn_top + int(btn_h * 0.2),
            int(W * 0.35), btn_h,
            '[ Zurück ] = Beenden', font='font13', textColor='0xFF888888'
        )
        self.addControl(self.lbl_hint)

        # User-Label rechts
        self.lbl_user = xbmcgui.ControlLabel(
            int(W * 0.72), btn_top + int(btn_h * 0.25),
            int(W * 0.27), btn_h,
            '', font='font13', textColor='0xFF5588aa',
            alignment=6
        )
        self.addControl(self.lbl_user)

        # Navigation (nur 2 Buttons)
        self.btn_write.controlRight(self.btn_close)
        self.btn_write.controlLeft(self.btn_close)
        self.btn_write.controlUp(self.msg_list)
        self.btn_close.controlLeft(self.btn_write)
        self.btn_close.controlRight(self.btn_write)
        self.btn_close.controlUp(self.msg_list)
        self.msg_list.controlDown(self.btn_write)

        self.setFocus(self.btn_write)

    def onFocus(self, controlId):
        ids = {
            self.btn_write.getId():  (self.btn_write_bg,  '0xFF00d4ff', '0xFF006688'),
            self.btn_close.getId():  (self.btn_close_bg,  '0xFFcc0033', '0xFF660018'),
        }
        for cid, (bg, focus_c, nofocus_c) in ids.items():
            try:
                bg.setColorDiffuse(focus_c if cid == controlId else nofocus_c)
            except Exception:
                pass

    # ── Start ────────────────────────────────────────────────────────────
    def start(self):
        self._reload()
        self._update_user_label()

        t = threading.Thread(target=self._poll_loop, daemon=True)
        t.start()

        self.doModal()
        self._stop.set()

    # ── Polling ──────────────────────────────────────────────────────────
    def _poll_loop(self):
        while not self._stop.is_set():
            self._stop.wait(POLL_INTERVAL)
            if self._stop.is_set():
                break
            msgs = api_get()
            if msgs is None:
                continue
            with self._lock:
                if len(msgs) != self._last_count:
                    self._msgs       = msgs
                    self._last_count = len(msgs)
                    self._changed    = True
            if self._changed:
                self._changed = False
                self._render_messages(self._msgs)
                self.lbl_status.setLabel('● Online ' + time.strftime('%H:%M:%S'))

    # ── Laden & Rendern ──────────────────────────────────────────────────
    def _reload(self):
        msgs = api_get()
        if msgs is not None:
            with self._lock:
                self._msgs       = msgs
                self._last_count = len(msgs)
        self._render_messages(self._msgs)
        ok = msgs is not None
        self.lbl_status.setLabel(
            ('● Online ' if ok else '● Fehler ') + time.strftime('%H:%M:%S')
        )

    def _render_messages(self, msgs):
        self.msg_list.reset()
        if not msgs:
            item = xbmcgui.ListItem(label='  Noch keine Nachrichten.')
            self.msg_list.addItem(item)
            return
        for m in msgs:
            t   = m.get('time', '')
            n   = m.get('name', '?')
            txt = m.get('message', '')
            item = xbmcgui.ListItem(label=f'[COLOR FF5588aa]{t}[/COLOR]  [COLOR FF00ccff]{n}:[/COLOR]  {txt}')
            self.msg_list.addItem(item)

    def _update_user_label(self):
        lock = '🔓' if self.auth else '🔒'
        self.lbl_user.setLabel(f'{lock}  {self.name}')

    # ── Events ───────────────────────────────────────────────────────────
    def onAction(self, action):
        act = action.getId()

        # Zurück / Esc → schließen
        if act in (ACTION_BACK, ACTION_PREVIOUS_MENU):
            self.close()
            return

        # OK-Taste & FireTV Remote Select → fokussierten Button auslösen
        if act in (ACTION_SELECT, ACTION_REMOTE_SELECT):
            try:
                focused = self.getFocusId()
                self._handle(focused)
            except Exception:
                pass
            return

        # Maus-Klick / Touch-Tap
        if act in (ACTION_MOUSE_LEFT, ACTION_TOUCH_TAP):
            try:
                focused = self.getFocusId()
                self._handle(focused)
            except Exception:
                pass

    def onClick(self, controlId):
        self._handle(controlId)

    def _handle(self, controlId):
        if controlId in (self.btn_write.getId(), self.btn_write_bg.getId()):
            self._do_write()
        elif controlId in (self.btn_close.getId(), self.btn_close_bg.getId()):
            self.close()

    # ── Schreiben ────────────────────────────────────────────────────────
    def _do_write(self):
        if not self.auth:
            kb = xbmc.Keyboard('', 'Chat-Passwort', True)
            kb.doModal()
            if not kb.isConfirmed():
                return
            self.pw = kb.getText().strip()

        kb = xbmc.Keyboard('', 'Deine Nachricht')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            return
        message = kb.getText().strip()

        res = api_post(self.name, message, self.pw)
        if res.get('success'):
            self.auth = True
            self._update_user_label()
            xbmcgui.Dialog().notification(ADDON_NAME, '✓ Gesendet!',
                xbmcgui.NOTIFICATION_INFO, 2000)
            self._reload()
        else:
            err = res.get('error', 'Fehler')
            xbmcgui.Dialog().notification(ADDON_NAME, f'✗ {err}',
                xbmcgui.NOTIFICATION_ERROR, 3000)
            if 'Passwort' in err:
                self.auth = False
                self.pw   = ''
                self._update_user_label()


# ─── Entry Point ─────────────────────────────────────────────────────────────
def main():
    kb = xbmc.Keyboard('', 'Dein Name im Chat')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return
    name = kb.getText().strip()

    win = ChatWindow(chat_name=name)
    win.start()
    del win

if __name__ == '__main__':
    main()
