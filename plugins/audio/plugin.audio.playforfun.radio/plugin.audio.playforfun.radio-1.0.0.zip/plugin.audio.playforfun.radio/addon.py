# -*- coding: utf-8 -*-
import sys
import os

addon_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(addon_path, "resources", "lib"))

try:
    from urllib.parse import parse_qsl, urlencode
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

import api
import favorites
import player_window

ADDON      = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]


def build_url(params):
    safe = {k: str(v) for k, v in params.items()}
    return "{}?{}".format(BASE_URL, urlencode(safe))


def get_params():
    qs = sys.argv[2].lstrip("?")
    return dict(parse_qsl(qs))


def notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=2500):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, ms)


def main_menu():
    entries = [
        ("[Radio] Sender suchen",   {"mode": "search_rb"}),
        ("[laut.fm] Sender suchen", {"mode": "search_laut"}),
        ("Favoriten",               {"mode": "favs"}),
        ("-- Stoppen --",           {"mode": "stop"}),
    ]
    for label, p in entries:
        item = xbmcgui.ListItem(label)
        item.setArt({"icon": "DefaultMusicSongs.png"})
        xbmcplugin.addDirectoryItem(HANDLE, build_url(p), item, isFolder=True)
    xbmcplugin.setPluginCategory(HANDLE, "PlayForFun Radio")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def render_rb(stations, category="Radio"):
    if not stations:
        notify("Keine Sender gefunden", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return
    for st in stations:
        name   = (st.get("name") or "Unbekannt").strip()
        stream = st.get("url_resolved") or st.get("url", "")
        if not stream:
            continue
        logo    = st.get("favicon") or ""
        tags    = st.get("tags") or ""
        bitrate = st.get("bitrate") or 0
        codec   = st.get("codec") or ""
        country = st.get("countrycode") or ""
        uuid    = st.get("stationuuid") or stream
        parts   = [x for x in [country, codec,
                   "{}kbps".format(bitrate) if bitrate else ""] if x]
        sub     = " | ".join(parts)
        item = xbmcgui.ListItem(name)
        item.setProperty("IsPlayable", "true")
        item.setInfo("music", {"title": name, "genre": tags[:80], "comment": sub})
        item.setArt({"icon": logo, "thumb": logo} if logo else {"icon": "DefaultMusicSongs.png"})
        is_fav = favorites.is_fav(uuid)
        item.addContextMenuItems([
            ("Favorit entfernen" if is_fav else "Zu Favoriten",
             "RunPlugin({})".format(build_url({
                 "mode": "rm_fav" if is_fav else "add_fav",
                 "uuid": uuid, "name": name,
                 "stream": stream, "logo": logo, "group": sub,
             })))
        ])
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({"mode": "play", "stream": stream,
                       "name": name, "logo": logo, "uuid": uuid}),
            item, isFolder=False)
    xbmcplugin.setPluginCategory(HANDLE, category)
    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def render_laut(stations):
    if not stations:
        notify("Keine laut.fm Sender gefunden", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return
    for st in stations:
        name = (st.get("display_name") or st.get("name") or "").strip()
        slug = st.get("name") or ""
        if not slug:
            continue
        stream = "https://stream.laut.fm/{}".format(slug)
        genres_raw = st.get("genres") or []
        genres = ", ".join(
            g.get("title", str(g)) if isinstance(g, dict) else str(g)
            for g in genres_raw[:3])
        imgs = st.get("images") or {}
        logo = (imgs.get("station") or imgs.get("background") or
                st.get("image_url") or "") if isinstance(imgs, dict) else ""
        uid = "lautfm_" + slug
        item = xbmcgui.ListItem("[laut.fm] " + name)
        item.setProperty("IsPlayable", "true")
        item.setInfo("music", {"title": name, "genre": genres, "comment": "laut.fm"})
        item.setArt({"icon": logo, "thumb": logo} if logo else {"icon": "DefaultMusicSongs.png"})
        is_fav = favorites.is_fav(uid)
        item.addContextMenuItems([
            ("Favorit entfernen" if is_fav else "Zu Favoriten",
             "RunPlugin({})".format(build_url({
                 "mode": "rm_fav" if is_fav else "add_fav",
                 "uuid": uid, "name": name,
                 "stream": stream, "logo": logo, "group": "laut.fm",
             })))
        ])
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({"mode": "play", "stream": stream,
                       "name": name, "logo": logo, "uuid": uid}),
            item, isFolder=False)
    xbmcplugin.setPluginCategory(HANDLE, "laut.fm")
    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def play(p):
    stream    = p.get("stream", "")
    name      = p.get("name", "Radio")
    logo      = p.get("logo", "")
    uuid      = p.get("uuid", "")
    laut_slug = ""

    if not stream:
        notify("Kein Stream", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if "stream.laut.fm/" in stream:
        laut_slug = stream.split("stream.laut.fm/")[1].split("?")[0].split("/")[0]

    if uuid and not uuid.startswith("lautfm_"):
        try:
            api.rb_click(uuid)
        except Exception:
            pass

    item = xbmcgui.ListItem(name)
    item.setProperty("IsPlayable", "true")
    item.setProperty("mimetype", "audio/mpeg")
    item.setInfo("music", {"title": name, "mediatype": "song"})
    item.setPath(stream)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)

    xbmc.sleep(1500)
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    win = player_window.RadioPlayerWindow(
        "script-playforfun-player.xml",
        addon_path, "Default", "1080i",
        station_name=name,
        station_logo="",
        stream_url=stream,
        laut_slug=laut_slug,
    )
    win.doModal()
    del win


def search_rb():
    kb = xbmc.Keyboard("", "Sender suchen")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    pd = xbmcgui.DialogProgress()
    pd.create(ADDON_NAME, "Suche...")
    stations = api.rb_search(query=query, limit=50)
    pd.close()
    render_rb(stations, "Suche: " + query)


def search_laut():
    kb = xbmc.Keyboard("", "laut.fm suchen")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    pd = xbmcgui.DialogProgress()
    pd.create(ADDON_NAME, "Suche...")
    stations = api.lautfm_search(query)
    pd.close()
    render_laut(stations)


def show_favs():
    favs = favorites.load()
    if not favs:
        notify("Keine Favoriten")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for st in favs:
        name   = st.get("name", "?")
        stream = st.get("url", "")
        logo   = st.get("logo", "")
        uid    = st.get("stationuuid") or stream
        item   = xbmcgui.ListItem("* " + name)
        item.setProperty("IsPlayable", "true")
        item.setInfo("music", {"title": name, "genre": st.get("group", "")})
        if logo:
            item.setArt({"icon": logo, "thumb": logo})
        item.addContextMenuItems([
            ("Favorit entfernen",
             "RunPlugin({})".format(build_url({"mode": "rm_fav", "uuid": uid})))
        ])
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url({"mode": "play", "stream": stream,
                       "name": name, "logo": logo, "uuid": uid}),
            item, isFolder=False)
    clr = xbmcgui.ListItem("--- Alle loeschen ---")
    xbmcplugin.addDirectoryItem(
        HANDLE, build_url({"mode": "clr_favs"}), clr, isFolder=True)
    xbmcplugin.setPluginCategory(HANDLE, "Favoriten ({})".format(len(favs)))
    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def add_fav(p):
    favorites.add({
        "stationuuid": p.get("uuid", ""),
        "name":  p.get("name", ""),
        "url":   p.get("stream", ""),
        "logo":  p.get("logo", ""),
        "group": p.get("group", ""),
    })
    notify("Favorit gespeichert")
    xbmc.executebuiltin("Container.Refresh")


def rm_fav(p):
    favorites.remove(p.get("uuid", ""))
    notify("Favorit entfernt")
    xbmc.executebuiltin("Container.Refresh")


def clr_favs():
    if xbmcgui.Dialog().yesno(ADDON_NAME, "Alle Favoriten loeschen?"):
        favorites.clear()
        notify("Geleert")
        xbmc.executebuiltin("Container.Refresh")


def router():
    p    = get_params()
    mode = p.get("mode", "main")
    if   mode == "main":        main_menu()
    elif mode == "search_rb":   search_rb()
    elif mode == "search_laut": search_laut()
    elif mode == "favs":        show_favs()
    elif mode == "add_fav":     add_fav(p)
    elif mode == "rm_fav":      rm_fav(p)
    elif mode == "clr_favs":    clr_favs()
    elif mode == "play":        play(p)
    elif mode == "stop":
        xbmc.Player().stop()
        notify("Gestoppt")
    else:
        main_menu()


if __name__ == "__main__":
    router()
