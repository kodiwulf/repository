# -*- coding: utf-8 -*-
import json
import random

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, quote
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import urlencode, quote

import xbmc

UA = "PlayForFunRadio/1.0 (Kodi)"
LAUTFM_API = "https://api.laut.fm"
RB_HOSTS = [
    "de1.api.radio-browser.info",
    "nl1.api.radio-browser.info",
    "at1.api.radio-browser.info",
]
_last_error = [""]


def _get(url, timeout=20):
    try:
        req = Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
        resp = urlopen(req, timeout=timeout)
        return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        _last_error[0] = str(e)
        xbmc.log("PFFRadio: {} -> {}".format(url, str(e)), xbmc.LOGERROR)
        return None


def rb_search(query="", country="", limit=50):
    params = {"limit": str(limit), "order": "votes", "reverse": "true", "hidebroken": "true"}
    if query:
        params["name"] = query
    if country:
        params["countrycode"] = country
    for host in RB_HOSTS:
        url = "https://{}/json/stations/search?{}".format(host, urlencode(params))
        result = _get(url)
        if isinstance(result, list) and result:
            return result
    return []


def rb_click(uuid):
    try:
        host = random.choice(RB_HOSTS)
        urlopen(Request(
            "https://{}/json/url/{}".format(host, uuid),
            headers={"User-Agent": UA}
        ), timeout=5)
    except Exception:
        pass


def lautfm_search(query, limit=60):
    url = "{}/search/stations?query={}&limit={}".format(LAUTFM_API, quote(query), limit)
    data = _get(url)
    if not data:
        return []
    seen = set()
    stations = []
    items = data if isinstance(data, list) else data.get("results", [])
    for item in items:
        if not isinstance(item, dict):
            continue
        sub_items = item.get("items")
        if sub_items is not None:
            for sub in sub_items:
                st = sub.get("station", sub) if isinstance(sub, dict) else sub
                if isinstance(st, dict):
                    name = st.get("name", "")
                    if name and name not in seen:
                        seen.add(name)
                        stations.append(st)
        else:
            name = item.get("name", "")
            if name and name not in seen:
                seen.add(name)
                stations.append(item)
    return stations
