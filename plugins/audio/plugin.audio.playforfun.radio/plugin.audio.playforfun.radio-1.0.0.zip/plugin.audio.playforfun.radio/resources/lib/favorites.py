# -*- coding: utf-8 -*-
"""
Favorites management using Kodi addon data storage.
"""
import json
import os

try:
    import xbmcaddon
    ADDON = xbmcaddon.Addon()
    try:
        import xbmcvfs
        DATA_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    except Exception:
        try:
            import xbmc
            DATA_PATH = xbmc.translatePath(ADDON.getAddonInfo("profile"))
        except Exception:
            DATA_PATH = ""
except Exception:
    DATA_PATH = ""

FAV_FILE = os.path.join(DATA_PATH, "favorites.json") if DATA_PATH else "favorites.json"


def _ensure_dir():
    if DATA_PATH and not os.path.exists(DATA_PATH):
        try:
            os.makedirs(DATA_PATH)
        except Exception:
            pass


def load():
    """Load favorites from file. Returns list of station dicts."""
    _ensure_dir()
    try:
        if os.path.exists(FAV_FILE):
            with open(FAV_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return []


def save(favs):
    """Save favorites list to file."""
    _ensure_dir()
    try:
        with open(FAV_FILE, "w", encoding="utf-8") as f:
            json.dump(favs, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def add(station):
    """Add station to favorites. station = dict with name, url, logo, group."""
    favs = load()
    uid = station.get("stationuuid") or station.get("url", "")
    # Remove duplicate
    favs = [f for f in favs if f.get("stationuuid") != uid and f.get("url") != uid]
    favs.insert(0, station)
    save(favs)


def remove(uid):
    """Remove station by uuid or url."""
    favs = load()
    favs = [f for f in favs if f.get("stationuuid") != uid and f.get("url") != uid]
    save(favs)


def is_fav(uid):
    """Check if station is in favorites."""
    return any(
        f.get("stationuuid") == uid or f.get("url") == uid
        for f in load()
    )


def clear():
    """Clear all favorites."""
    save([])
