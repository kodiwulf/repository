# -*- coding: utf-8 -*-
import json
import threading
import time

try:
    from urllib.request import urlopen, Request
    from urllib.parse import quote
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import quote

import xbmc
import xbmcgui
import xbmcaddon

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
UA         = "PlayForFunRadio/1.0"

BTN_PLAYPAUSE = 100
BTN_STOP      = 101
BTN_CLOSE     = 102
LBL_NOWPLAY   = 12


def get_lautfm_nowplaying(slug):
    try:
        url = "https://api.laut.fm/station/{}/current_song".format(quote(slug))
        req = Request(url, headers={"User-Agent": UA})
        data = json.loads(urlopen(req, timeout=6).read().decode("utf-8"))
        artist = data.get("artist", {})
        if isinstance(artist, dict):
            artist = artist.get("name", "")
        title = data.get("title", "")
        if title:
            return "{} - {}".format(artist, title) if artist else title
    except Exception:
        pass
    return None


def get_icy_nowplaying():
    try:
        player = xbmc.Player()
        if not player.isPlaying():
            return None
        tag = player.getMusicInfoTag()
        t = tag.getTitle() or ""
        a = tag.getArtist() or ""
        if a and t:
            return "{} - {}".format(a, t)
        return t or None
    except Exception:
        return None


class RadioPlayerWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.station_name = kwargs.get("station_name", "Radio")
        self.station_logo = kwargs.get("station_logo", "")
        self.stream_url   = kwargs.get("stream_url", "")
        self.laut_slug    = kwargs.get("laut_slug", "")
        self._running     = True
        self._thread      = None

    def onInit(self):
        try:
            self.getControl(LBL_NOWPLAY).setLabel("Verbinde...")
        except Exception:
            pass
        # Force focus to PLAY button so remote control works immediately
        self.setFocus(self.getControl(BTN_PLAYPAUSE))
        self._running = True
        self._thread  = threading.Thread(target=self._update_loop)
        self._thread.daemon = True
        self._thread.start()

    def _update_loop(self):
        last_info = ""
        while self._running:
            try:
                info = None
                if self.laut_slug:
                    info = get_lautfm_nowplaying(self.laut_slug)
                if not info:
                    info = get_icy_nowplaying()
                if info and info != last_info:
                    last_info = info
                    try:
                        self.getControl(LBL_NOWPLAY).setLabel(info)
                    except Exception:
                        pass
                elif not info and not last_info:
                    try:
                        self.getControl(LBL_NOWPLAY).setLabel("Live Radio")
                    except Exception:
                        pass
            except Exception as e:
                xbmc.log("PFFRadio update error: " + str(e), xbmc.LOGERROR)

            for _ in range(30):
                if not self._running:
                    return
                xbmc.sleep(500)

    def onClick(self, control_id):
        player = xbmc.Player()
        if control_id == BTN_PLAYPAUSE:
            if player.isPlaying():
                player.pause()
            else:
                if self.stream_url:
                    item = xbmcgui.ListItem(self.station_name)
                    item.setProperty("IsPlayable", "true")
                    item.setPath(self.stream_url)
                    player.play(self.stream_url, item)
        elif control_id == BTN_STOP:
            player.stop()
            try:
                self.getControl(LBL_NOWPLAY).setLabel("Gestoppt")
            except Exception:
                pass
        elif control_id == BTN_CLOSE:
            self._running = False
            self.close()

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU,
                               xbmcgui.ACTION_NAV_BACK):
            self._running = False
            self.close()

    def close(self):
        self._running = False
        super(RadioPlayerWindow, self).close()
