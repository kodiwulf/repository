#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,os,re,time, sys
import xbmcaddon,xbmcplugin,xbmcgui,xbmc,resolveurl
from contextlib import closing
from urllib.parse import urlparse

player_ = xbmc.Player()

def fix_encoding(path):
	if sys.platform.startswith('win'):return path
	else:return path 

_addon_ =  xbmcaddon.Addon()
_addon_id_ = _addon_.getAddonInfo('id')
_addon_path_ = fix_encoding(_addon_.getAddonInfo('path'))

sys.path.append(os.path.join(_addon_path_,'resources','lib'))
import requests,cfscraper

dbg = False
pluginhandle = int(sys.argv[1])

itemcnt = 0
baseurl = 'https://filmpalast.to'
streamurl = 'https://filmpalast.to/stream/{id}/1'
settings = xbmcaddon.Addon(id='plugin.video.filmpalast_to')
maxitems = (int(settings.getSetting("items_per_page"))+1)*32
forceViewMode = settings.getSetting("forceViewMode") == 'true'
viewMode = str(settings.getSetting("viewMode"))
showRating = settings.getSetting("showRating") == 'true'
showVotes = settings.getSetting("showVotes") == 'true'
showMovieInfo = settings.getSetting("showMovieInfo") == 'true'
userAgent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.80 Safari/537.36'

def get_image(image):
    return os.path.join(_addon_path_, 'resources', 'images', image)

def get_request(url,stream=False,timeout=30,scraper_delay=0,headers_dict={}):
    if url.startswith('//'):url = 'https:' + url
    with closing(cfscraper.create_scraper(scraper_delay)) as scraper:
        return scraper.get(url,stream=stream,allow_redirects=False,timeout=timeout,headers=headers_dict)

def set_content_type(content_type='files'):
    xbmcplugin.setContent(pluginhandle, content_type)

def START():
    """
    Erstellt das Hauptmenü mit verschiedenen Optionen und nutzt Bilder aus dem lokalen Addon-Verzeichnis.
    """
    # Set content type for the main menu to 'movies'
    set_content_type('video')

    addDir(
        name='Neue Filme',
        url=baseurl + '/movies/new',
        mode=1,
        image=get_image('icon.png'),
        fanart=get_image('fanart.jpg'),  # Gültiges Bild verwenden
        description='Die neuesten Filme',
        is_folder=True
    )
    addDir(
        name='Neue Serien',
        url=baseurl + '/serien/view',
        mode=1,
        image=get_image('icon.png'),
        fanart=get_image('fanart.jpg'),
        description='Die neuesten Serien',
        is_folder=True
    )
    addDir(
        name='Top Filme',
        url=baseurl + '/movies/top',
        mode=1,
        image=get_image('icon.png'),
        fanart=get_image('fanart.jpg'),
        description='Die beliebtesten Filme',
        is_folder=True
    )
    addDir(
        name='Kategorien',
        url=baseurl,
        mode=2,
        image=get_image('icon.png'),
        fanart=get_image('fanart.jpg'),
        description='Durchsuche die Kategorien',
        is_folder=True
    )
    addDir(
        name='Alphabetisch',
        url=baseurl,
        mode=3,
        image=get_image('icon.png'),
        fanart=get_image('fanart.jpg'),
        description='Alphabetische Übersicht',
        is_folder=True
    )
    addDir(
        name='Suche...',
        url=baseurl + '/search/title/',
        mode=4,
        image=get_image('icon.png'),
        fanart=get_image('fanart.jpg'),
        description='Finde, wonach du suchst',
        is_folder=True
    )
    
    # Ansichtsmodus setzen, falls erforderlich
    if forceViewMode:
        xbmc.executebuiltin(f"Container.SetViewMode({viewMode})")


def CATEGORIES(url):
    
    set_content_type('tvshows')
    
    data = get_request(url).text
    for genre in re.findall('<section id="genre">(.*?)</section>', data, re.S|re.I):
        for (href, name) in re.findall('<a[^>]*href="([^"]*)">[ ]*([^<]*)</a>', genre, re.S|re.I):
            addDir(clean(name), href, 1, '', True)
    if forceViewMode: xbmc.executebuiltin("Container.SetViewMode("+viewMode+")")

def ALPHA():
    addDir('#', baseurl + '/search/alpha/0-9', 1, '', True)
    for char in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        addDir(char, baseurl + '/search/alpha/' + char, 1, '', True)
    if forceViewMode: xbmc.executebuiltin("Container.SetViewMode("+viewMode+")")

def INDEX(caturl):
    global itemcnt
    data = get_request(caturl).text

    # Parse entries within content
    for entry in re.findall(r'id="content"[^>]*>(.+?)<[^>]*id="paging"', data, re.S | re.I):
        for rating, url, title, image in re.findall(
            r'</cite>(.*?)<a[^>]*href="([^"]*)"[^>]*title="([^"]*)"[^>]*>[^<]*<img[^>]*src=["\']([^"\']*)["\'][^>]*>',
            entry, re.S | re.I
        ):
            if not url.startswith('http:'):
                url = url
            if not image.startswith('http:'):
                image = baseurl + image

            if showRating:
                stars = len(re.findall(r'star_on.png', rating, re.S | re.I))
                title += f"  [COLOR=lime]{stars}/10[/COLOR]"

            if showVotes:
                votes = re.findall(r'<sm.*?p;(.*?)&nbsp.*?ll>', rating, re.S | re.I)
                if votes:
                    title += f"  [COLOR=lime]({votes[0]} votes)[/COLOR]"

            addLink(clean(title), url, 10, image)
            itemcnt += 1

    # Handle pagination
    nextPage = re.findall(
        r'<a[^>]*class="[^\"]*pageing[^\"]*"[^>]*href=["\']([^"\']*)["\'][^>]*>[ ]*vorw',
        data, re.S | re.I
    )

    if nextPage:
        if itemcnt >= maxitems:
            addDir('Weiter >>', nextPage[0], 1, '', True)
        else:
            INDEX(nextPage[0])

    if forceViewMode:
        xbmc.executebuiltin(f"Container.SetViewMode({viewMode})")

def SEARCH(url):
    keyboard = xbmc.Keyboard('', 'Suche')
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        search_string = urllib.parse.quote_plus(keyboard.getText())
        INDEX(url + search_string)

def clean(s):
    matches = re.findall("&#\d+;", s)
    for hit in set(matches):
        try: s = s.replace(hit, unichr(int(hit[2:-1])))
        except ValueError: pass
    return urllib.parse.unquote_plus(s)

def selectVideoDialog(videos, data):
    """
    Zeigt ein Dialog-Menü mit erweiterten Informationen an, um den gewünschten Host auszuwählen.

    :param videos: Liste der verfügbaren Videos [(hoster, url), ...]
    :param data: HTML-Daten oder zusätzliche Informationen
    :return: URL des ausgewählten Videos oder None
    """
    dialog = xbmcgui.Dialog()

    # Erstelle die Optionen für den Dialog
    options = []

    # Extrahiere zusätzliche Informationen aus den Daten
    if data:
        info = getInfos(data)
        details = [
            f"[COLOR=lime]FP: {info['fp']} | IMDb: {info['imdb']}[/COLOR]",
            f"[COLOR=lime]Jahr: {info['year']} | Laufzeit: {info['runtime']}[/COLOR]",
            f"[COLOR=lime]Genres: {info['genres']}[/COLOR]",
            f"[COLOR=lime]Darsteller: {info['actors']}[/COLOR]",
            f"[COLOR=lime]Beschreibung: {info['description']}[/COLOR]",
        ]
        # Füge die Details als eine einzelne Option hinzu
        options.append("\n".join(filter(bool, details)))

    # Füge die Video-Hoster hinzu
    options.extend([f"[B]{hoster}[/B]" for hoster, _ in videos])

    # Zeige den Dialog an und warte auf die Auswahl
    selected = dialog.select("Verfügbare Hoster", options)

    if data and selected == 0:  # Nur Zusatzinfo ausgewählt
        return None
    elif selected > 0:  # Falls der Benutzer eine Auswahl getroffen hat
        return videos[selected - 1][1]  # -1, da die erste Zeile Zusatzinfo ist

    return None  # Falls der Benutzer den Dialog abbricht

def getInfos(data):
    """
    Extrahiert Informationen aus HTML-Daten.

    :param data: HTML-Quellcode oder Text
    :return: Dictionary mit den extrahierten Informationen
    """
    info = {
        'fp': '',
        'imdb': '',
        'genres': '',
        'actors': '',
        'year': '',
        'runtime': '',
        'description': ''
    }

    # FP und IMDb-Bewertungen
    match = re.search(r'average">([0-9,.]{0,3})<.*?; Imdb: ([0-9,.]{0,3})/10', data, re.S | re.I)
    if match:
        info['fp'] = match.group(1)
        info['imdb'] = match.group(2)

    # Jahr und Laufzeit
    match = re.search(r'>Ver&ouml;ffentlicht: ([^\n]*).*?>Spielzeit:.*?>(.*?)<', data, re.S | re.I)
    if match:
        info['year'] = match.group(1).replace('false', '').strip()
        info['runtime'] = match.group(2).strip()

    # Beschreibung
    match = re.search(r'itemprop="description">(.*?)<', data, re.S | re.I)
    if match:
        info['description'] = match.group(1).strip()

    # Genres
    genres = re.findall(r'class="rb"[^>]*genre/(.*?)"', data, re.S | re.I | re.DOTALL)
    info['genres'] = ' / '.join(genres).strip()

    # Schauspieler
    actors = re.findall(r'class="rb".*?"/search/title/(.*?)"', data, re.S | re.I | re.DOTALL)
    info['actors'] = ' / '.join(actors).strip()

    return info

def PLAYVIDEO(url):
    data = get_request(url).text
    if not data:
        xbmc.executebuiltin("XBMC.Notification(Fehler!, Keine Daten abgerufen, 4000)")
        return

    # Extrahiere Videos aus dem HTML-Inhalt
    videos = [
        (hoster, stream.replace('\\/', '/'))
        for hoster, stream in re.findall(r'hostName">([^<]+).*?(http[^"]+)', data, re.S | re.I)
    ]

    if not videos:
        xbmc.executebuiltin("XBMC.Notification(Fehler!, Video nicht gefunden, 4000)")
        return

    # Extrahiere zusätzliche Informationen
    infodata_match = re.search(r'id="star-rate"(.*?)<[^>]*class="currentTabInfo">', data, re.S | re.I)
    additional_info = infodata_match.group(1) if infodata_match else ""

    # Wähle ein Video aus, falls mehrere verfügbar sind
    selected_url = (
        selectVideoDialog(videos, additional_info)
        if len(videos) > 1 else videos[0][1]
    )

    if selected_url:
        stream_url = GetStream(selected_url)
        if stream_url:
            listitem = xbmcgui.ListItem(path=stream_url)
            xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

# Funktion zum Abrufen des Streams von einer URL
def GetStream(url):
    if 'filmpalast.to' in url:
        headers = {
            'User-Agent': userAgent,
            'Origin': 'filmpalast.to',
            'Host': 'filmpalast.to',
            'Referer': url
        }

        response = get_request(url, headers_dict=headers)

        # Folge Weiterleitungen, falls vorhanden
        if response.status_code in [301, 302]:
            url = response.headers.get('Location', response.url)

        response.close()

    # Überprüfen, ob die URL gültig ist
    source = resolveurl.HostedMediaFile(url=url)
    if source.valid_url():
        if player_.isPlaying():
            # Stoppe den Player, falls ein anderes Video läuft
            end_time = time.time() + 5
            while player_.isPlaying() and time.time() < end_time:
                player_.stop()

        return source.resolve()

    return ''

def get_params():
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = paramstring.lstrip('?').rstrip('/')
        pairs = params.split('&')
        return {key: value for key, value in (pair.split('=') for pair in pairs if '=' in pair)}
    return {}

def addLink(name, url, mode, image, fanart=None):
    u = f"{sys.argv[0]}?url={urllib.parse.quote_plus(url)}&mode={mode}"
    liz = xbmcgui.ListItem(label=name)
    liz.setInfo("video", {"Title": name})
    liz.setProperty('IsPlayable', 'true')
    liz.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart or image})
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)

def addDir(name, url, mode, image=None, fanart=None, description=None, is_folder=True):
    """
    Fügt einen neuen Eintrag zu einem Kodi-Menü hinzu.
    
    :param name: Name des Eintrags
    :param url: Ziel-URL oder Aktion
    :param mode: Modus zur Identifikation der Aktion
    :param image: Pfad zum Vorschaubild
    :param fanart: Pfad zum Hintergrundbild (Fanart)
    :param description: Beschreibung des Eintrags
    :param is_folder: Gibt an, ob der Eintrag ein Ordner ist (True) oder nicht (False)
    """
    set_content_type('video')
    
    # URL zusammenstellen
    u = f"{sys.argv[0]}?url={urllib.parse.quote_plus(url)}&mode={mode}"
    
    # ListItem erstellen
    list_item = xbmcgui.ListItem(label=name)
    list_item.setInfo(type="Video", infoLabels={"Title": name, "Plot": description or ""})
    
    # Grafiken setzen
    if image:
        list_item.setArt({'thumb': image, 'icon': image, 'poster': image})
    
    # Sicherstellen, dass fanart ein String ist
    if not isinstance(fanart, str):
        fanart = str(fanart or "")  # Falls fanart None oder anderes Format, leeren String setzen
    
    # Fanart Bild setzen
    list_item.setProperty('fanart_image', fanart)
    
    # Verzeichnis- oder Elementhinzufügen
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=list_item, isFolder=is_folder)

params = get_params()
url = urllib.parse.unquote_plus(params.get("url", ""))
mode = int(params.get("mode", -1))  # Standardwert -1, um ungültigen Modus zu erkennen

if not url or mode == -1:
    START()
else:
    actions = {
        1: lambda: INDEX(url),
        2: lambda: CATEGORIES(url),
        3: ALPHA,
        4: lambda: SEARCH(url),
        10: lambda: PLAYVIDEO(url)
    }
    action = actions.get(mode, START)
    action()


xbmcplugin.endOfDirectory(handle=pluginhandle,succeeded=True,updateListing=False,cacheToDisc=True)