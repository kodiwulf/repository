#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys
import xbmc,xbmcgui,xbmcaddon,xbmcplugin,xbmcvfs

def fix_encoding(path):
	if sys.platform.startswith('win'):return unicode(path,'utf-8')
	else:return unicode(path,'utf-8').encode('ISO-8859-1')
	
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')

def set_content(content):
	xbmcplugin.setContent(int(sys.argv[1]),content)

def set_view_mode(view_mode):
    xbmc.executebuiltin('Container.SetViewMode(%s)' % (view_mode))

def set_end_of_directory(succeeded=True,updateListing=False,cacheToDisc=False):
	xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True,updateListing=False,cacheToDisc=False)

def get_youtube_live_stream(channel_id):# is_folder_bool=False
	return'plugin://plugin.video.youtube/play/?channel_id=%s&live=1' % channel_id

def get_youtube_video(video_id):# is_folder_bool=False
	return'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id

def get_youtube_playlist(playlist_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/playlist/%s/' % playlist_id

def get_youtube_channel(channel_id):# is_folder_bool=True
	return'plugin://plugin.video.youtube/channel/%s/' % channel_id

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')
icon_path = os.path.join(addon_path,'resources','icon')
xbmcplugin.setContent(handle=int(sys.argv[1]), content='songs')
				
def add_item(name, url, iconimage='',
isFolder=True, IsPlayable=False):
    urlParams = {'name': name, 'url': url, 'iconimage': iconimage}
    liz = xbmcgui.ListItem(name, iconimage, iconimage)
    liz.setArt({'icon': iconimage, 'thumb' : iconimage})
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    return ok

#-------------------#
#set_view_mode('50')
set_content('movies')
#-----------------------------------------------------------------------------------------------#

addon = xbmcaddon.Addon()
pluginhandle = int(sys.argv[1])
addonID = addon.getAddonInfo('id')
icon1=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/GT100.jpg')
icon2=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/100SChlager.jpg')
icon4=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Itunes.webp')
icon5=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Billboard.jpg')
icon6=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/MTV.jpg')
icon7=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Tomorrow.jpg')
icon8=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Pop Music.jpeg')
icon9=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Dance2.jpg')
icon10=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Dance5.jpg')
icon11=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Dance4.jpg')
icon12=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/vevo.jpg')
icon13=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Deluxemusic.png')
icon14=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/2000er Hits.jpg')
icon15=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Eurodance.jpg')
icon16=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/90s.jpg')
icon17=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Disco.jpg')
icon18=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Neue deutsche Welle.jpg')
icon19=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Top 70er.jpg')
icon20=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/60Ss.jpg')
icon21=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Heavy Metal Rock.png')
icon22=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/AC-DC.jpg')
icon23=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Metallica.jpg')
icon24=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Rock Musik.jpg')
icon25=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Party Rock.jpg')
icon26=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/70er Rock.png')
icon27=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Love Songs.jpg')
icon3=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Musik Mix.jpg')
icon28=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/Kuschel Rock.jpg')
icon29=xbmcvfs.translatePath('special://home/addons/plugin.video.All.Kinds.of.Music/reggea.png')


add_item('German TOP 100 Single Charts',get_youtube_playlist('PLw-VjHDlEOgtl4ldJJ8Arb2WeSlAyBkJS'),icon1)
add_item('Top 100 Schlager Charts',get_youtube_playlist('PLB5axqo_BYe1JqK7mXkjhx-4p_qiAw-5I'),icon2)
add_item('Apple Music Top Charts ',get_youtube_playlist('PLOEBvKK_FE98E9Jx8RHHerxMdmFMfOVy3'),icon4)
add_item('Billboard Charts',get_youtube_playlist('PLD7SPvDoEddZUrho5ynsBfaI7nqhaNN5c'),icon5)
add_item('MTV Hits 2023 - Top 100 Charts Germany"',get_youtube_playlist('PL3-sRm8xAzY-YDhgZbycXLPnsue_mhU6B'),icon6)
add_item('Tomorrowland,Parokaville,Defcon,Qlimax,Goa und Psytrance Festival',get_youtube_playlist('PLsGK3aH9-P9krMatVVQwTuraacMknlAeB'),icon7)
add_item('Best Pop Songs',get_youtube_playlist('PLMC9KNkIncKvYin_USF1qoJQnIyMAfRxl'),icon8)
add_item('Best Sounds of Summer',get_youtube_playlist('PLMC9KNkIncKtsacKpgMb0CVq43W80FKvo'),icon9)
add_item('4K Musik Mix',get_youtube_playlist('PLoj6YVKua1uJmN0GxnD7gRoASjnsS_ATD'),icon3)
add_item('Now Dance Musik',get_youtube_playlist('PLWlTX25IDqIwqowTsJmGhqxUWU_6qgG1W'),icon10)
add_item('Dance Hits',get_youtube_playlist('PL6Go6XFhidEAH6LrK-RKxR5xwhdZ0g4vm'),icon11)
add_item('Vevo Hits',get_youtube_playlist('PLDIoUOhQQPlWvtxdeVTG3i7-SlSN0jfWj'),icon12)
add_item('Deluxe Music Top 40 ',get_youtube_playlist('PLEh8j16QM7HwoQjONlH6Q5WIrpYwgLJ3_'),icon13)
add_item('2000s Party Music Hits',get_youtube_playlist('PL39z-AAkkats9VE4V8gdQyIjqp21nao9p'),icon14)
add_item('Best Eurodance Songs of 90er',get_youtube_playlist('PLVf3PXRSPQRarUyt_B_X7O1fm9mGpeqn4'),icon15)
add_item('Greatest 90s Music Hits',get_youtube_playlist('PL7DA3D097D6FDBC02'),icon16)
add_item('Best of 80-90er Hits',get_youtube_playlist('PLGBuKfnErZlCZed3VIG70mQBHPH7tKJ6D'),icon17)
add_item('Neue Deutsche Welle 80s',get_youtube_playlist('PLd5xnond3B5Q8RQpGlrlvZv0n4_hpvxNv'),icon18)
add_item('Best of the 70er',get_youtube_playlist('PL09eGQfW13QjtcB0nITNYP56g8OMKe0uc'),icon19)
add_item('Greatest hits of the 60s',get_youtube_playlist('PLGBuKfnErZlCkRRgt06em8nbXvcV5Sae7'),icon20)
add_item('Heavy Metal',get_youtube_playlist('PLWUXmX2htJ7Nx2_luG8WAVEnShOW-lGal'),icon21)
add_item('AC/DC',get_youtube_playlist('PLQlc99hV-nkGWDaG-gJxwOfqp8jxyHaaQ'),icon22)
add_item('Metallica',get_youtube_playlist('PL2D4A44B959D87893'),icon23)
add_item('Best Rock Music',get_youtube_playlist('PLQ1TuSoOt3w3aQr-obgpzr7EeeM_shwvp'),icon24)
add_item('Party Rock Songs',get_youtube_playlist('PLoumn5BIsUDdTFSnx5fSfQHQbnFtAJ5D2'),icon25)
add_item('70 Rock Music',get_youtube_playlist('PLAB1BFD67033229B4'),icon26)
add_item('Love Songs.',get_youtube_playlist('PL6BA2D5208E8EF161'),icon27)
add_item('Kuschelrock',get_youtube_playlist('PL4DpwjwvhozHu4cQH7VZAASvcEFF_Hioa'),icon28)
add_item('Best Reggae Music',get_youtube_playlist('PLb2aZl2AJg_VpTIQennzYzQVrA_fgRg7-'),icon29)


	
#-----------------------------------------------------------------------------------------------#

set_end_of_directory()