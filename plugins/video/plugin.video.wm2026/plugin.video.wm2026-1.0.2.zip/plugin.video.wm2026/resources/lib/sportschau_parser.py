# -*- coding: utf-8 -*-

import os
import json
import re
import unicodedata

from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs


SPORTSCHAU_URL = (
    "https://www.sportschau.de/fussball/"
    "fifa-wm-2026/"
    "der-spielplan-der-fussball-wm-2026,"
    "fifawm-spielplan-100.html"
)

OPENFOOTBALL_URL = (
    "https://raw.githubusercontent.com/"
    "openfootball/worldcup.json/master/2026/worldcup.json"
)

ADDON_ID = "plugin.video.wm2026"

ADDON = xbmcaddon.Addon(
    id=ADDON_ID
)

PROFILE_PATH = xbmcvfs.translatePath(
    ADDON.getAddonInfo("profile")
)

BROADCASTS_FILE = os.path.join(
    PROFILE_PATH,
    "broadcasts.json"
)

VALID_CHANNELS = [
    "ARD",
    "ZDF",
    "Magenta"
]


# ------------------------------------------------------------------
# Deutsche Teamnamen -> OpenFootball
# ------------------------------------------------------------------
TEAM_MAPPING = {

    "Deutschland": "Germany",
    "Südkorea": "South Korea",
    "Tschechien": "Czech Republic",

    "Bosnien-Herzegowina": "Bosnia & Herzegovina",
    "Bosnien-Herzegovina": "Bosnia & Herzegovina",
    "Bosnien & Herzegowina": "Bosnia & Herzegovina",

    "Schweiz": "Switzerland",
    "Brasilien": "Brazil",
    "Marokko": "Morocco",
    "Türkei": "Turkey",
    "Südafrika": "South Africa",
    "Mexiko": "Mexico",
    "Katar": "Qatar",
    "Australien": "Australia",
    "Schottland": "Scotland",
    "Elfenbeinküste": "Ivory Coast",
    "Niederlande": "Netherlands",
    "Vereinigte Staaten": "USA",
    "Saudi-Arabien": "Saudi Arabia",
    "Saudi Arabien": "Saudi Arabia",
    "Iran": "Iran",
    "Japan": "Japan",
    "Ägypten": "Egypt",
    "Spanien": "Spain",
    "Frankreich": "France",
    "Belgien": "Belgium",
    "Portugal": "Portugal",
    "England": "England",
    "Ghana": "Ghana",
    "Panama": "Panama",
    "Kroatien": "Croatia",
    "Kolumbien": "Colombia",
    "DR Kongo": "DR Congo",
    "Usbekistan": "Uzbekistan",
    "Jordanien": "Jordan",
    "Argentinien": "Argentina",
    "Algerien": "Algeria",
    "Österreich": "Austria",
    "Irak": "Iraq",
    "Norwegen": "Norway",
    "Senegal": "Senegal",
    "Uruguay": "Uruguay",
    "Kap Verde": "Cape Verde",
    "Neuseeland": "New Zealand",
    "Tunesien": "Tunisia",
    "Schweden": "Sweden",
    "Haiti": "Haiti",
    "Paraguay": "Paraguay",
    "Curaçao": "Curacao",
    "Ecuador": "Ecuador",
    "USA": "USA",

    "Vereinigte Arabische Emirate":
        "United Arab Emirates"
}


# ------------------------------------------------------------------
# Profilordner erstellen
# ------------------------------------------------------------------
def ensure_profile_path():

    if not xbmcvfs.exists(PROFILE_PATH):

        xbmcvfs.mkdirs(PROFILE_PATH)

        xbmc.log(
            f"[WM2026] Profilordner erstellt: "
            f"{PROFILE_PATH}",
            xbmc.LOGINFO
        )


# ------------------------------------------------------------------
# URL laden
# ------------------------------------------------------------------
def load_url(url, timeout=10):

    request = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0"
        }
    )

    response = urlopen(
        request,
        timeout=timeout
    )

    return response.read().decode(
        "utf-8"
    )


# ------------------------------------------------------------------
# OpenFootball Teams laden
# ------------------------------------------------------------------
def load_openfootball_teams():

    xbmc.log(
        "[WM2026] Lade OpenFootball Teams",
        xbmc.LOGINFO
    )

    data = json.loads(
        load_url(
            OPENFOOTBALL_URL,
            timeout=10
        )
    )

    teams = set()

    for match in data.get("matches", []):

        home = match.get(
            "team1",
            ""
        ).strip()

        away = match.get(
            "team2",
            ""
        ).strip()

        if home:

            teams.add(home)

        if away:

            teams.add(away)

    xbmc.log(
        f"[WM2026] {len(teams)} Teams geladen",
        xbmc.LOGINFO
    )

    return teams


# ------------------------------------------------------------------
# Sonderzeichen normalisieren
# ------------------------------------------------------------------
def normalize_ascii(text):

    text = unicodedata.normalize(
        "NFKD",
        text
    )

    text = text.encode(
        "ascii",
        "ignore"
    ).decode(
        "ascii"
    )

    return text.strip()


# ------------------------------------------------------------------
# Teamnamen normalisieren
# ------------------------------------------------------------------
def normalize_team(team, valid_teams):

    original_team = team.strip()

    normalized_team = TEAM_MAPPING.get(
        original_team,
        original_team
    )

    normalized_team = normalize_ascii(
        normalized_team
    )

    if normalized_team not in valid_teams:

        xbmc.log(
            f"[WM2026] Unbekanntes Team: "
            f"{original_team} -> {normalized_team}",
            xbmc.LOGDEBUG
        )

    return normalized_team


# ------------------------------------------------------------------
# Datum umwandeln
# ------------------------------------------------------------------
def convert_date(date_text):

    match = re.search(
        r"(\d{2})\.(\d{2})\.",
        date_text
    )

    if not match:

        return None

    day = match.group(1)
    month = match.group(2)

    return f"2026-{month}-{day}"


# ------------------------------------------------------------------
# Begegnung splitten
# ------------------------------------------------------------------
def split_match(match_text, valid_teams):

    separators = [
        " - ",
        " – ",
        "-",
        "–"
    ]

    for separator in separators:

        if separator in match_text:

            home, away = match_text.split(
                separator,
                1
            )

            home = normalize_team(
                home,
                valid_teams
            )

            away = normalize_team(
                away,
                valid_teams
            )

            return home, away

    return None, None


# ------------------------------------------------------------------
# Tabellenzeilen extrahieren
# ------------------------------------------------------------------
def extract_rows(html):

    pattern = re.compile(

        r"<tr>(.*?)</tr>",

        re.DOTALL | re.IGNORECASE
    )

    return pattern.findall(html)


# ------------------------------------------------------------------
# Tabellenzellen extrahieren
# ------------------------------------------------------------------
def extract_columns(row_html):

    pattern = re.compile(

        r"<td.*?>(.*?)</td>",

        re.DOTALL | re.IGNORECASE
    )

    return pattern.findall(row_html)


# ------------------------------------------------------------------
# HTML bereinigen
# ------------------------------------------------------------------
def clean_html(text):

    text = re.sub(
        r"<br\s*/?>",
        " ",
        text,
        flags=re.IGNORECASE
    )

    text = re.sub(
        r"<.*?>",
        "",
        text,
        flags=re.DOTALL
    )

    text = text.replace(
        "&nbsp;",
        " "
    )

    text = re.sub(
        r"\s+",
        " ",
        text
    )

    return text.strip()


# ------------------------------------------------------------------
# Sportschau parsen
# ------------------------------------------------------------------
def parse_sportschau():

    ensure_profile_path()

    valid_teams = load_openfootball_teams()

    xbmc.log(
        "[WM2026] Lade Sportschau Daten",
        xbmc.LOGINFO
    )

    html = load_url(
        SPORTSCHAU_URL,
        timeout=15
    )

    broadcasts = {}

    # --------------------------------------------------------------
    # Tabellenzeilen extrahieren
    # --------------------------------------------------------------
    rows = extract_rows(html)

    xbmc.log(
        f"[WM2026] {len(rows)} Tabellenzeilen gefunden",
        xbmc.LOGINFO
    )

    for row in rows:

        try:

            columns = extract_columns(row)

            xbmc.log(
                f"[WM2026 DEBUG] Spalten: {len(columns)}",
                xbmc.LOGINFO
            )

            for idx, col in enumerate(columns):

                xbmc.log(
                    f"[WM2026 DEBUG] COL[{idx}] = "
                    f"{clean_html(col)}",
                    xbmc.LOGINFO
                )

            if len(columns) < 4:

                xbmc.log(
                    "[WM2026 DEBUG] Zu wenig Spalten",
                    xbmc.LOGINFO
                )

                continue

            # ------------------------------------------------------
            # Datum
            # ------------------------------------------------------
            date_text = clean_html(
                columns[0]
            )

            date = convert_date(
                date_text
            )

            if not date:

                continue

            # ------------------------------------------------------
            # Begegnung
            # ------------------------------------------------------
            match_text = clean_html(
                columns[2]
            )

            home, away = split_match(
                match_text,
                valid_teams
            )

            if not home or not away:

                xbmc.log(
                    f"[WM2026] Match ungültig: "
                    f"{match_text}",
                    xbmc.LOGWARNING
                )

                continue

            # ------------------------------------------------------
            # TV Sender / Ergebnis
            # ------------------------------------------------------
            channel = clean_html(
                columns[3]
            )

            # ------------------------------------------------------
            # Match-Key
            # ------------------------------------------------------
            key = f"{home}_{away}_{date}"

            broadcasts[key] = channel

            xbmc.log(
                f"[WM2026] {key} -> {channel}",
                xbmc.LOGINFO
            )

        except Exception as e:

            xbmc.log(
                f"[WM2026] Tabellenzeile Fehler: {e}",
                xbmc.LOGERROR
            )

    return broadcasts


# ------------------------------------------------------------------
# JSON speichern
# ------------------------------------------------------------------
def save_json(data):

    try:

        with xbmcvfs.File(
            BROADCASTS_FILE,
            "w"
        ) as f:

            f.write(
                json.dumps(
                    data,
                    ensure_ascii=False,
                    indent=2
                )
            )

        xbmc.log(
            f"[WM2026] broadcasts.json gespeichert: "
            f"{BROADCASTS_FILE}",
            xbmc.LOGINFO
        )

    except Exception as e:

        xbmc.log(
            f"[WM2026] Save Error: {e}",
            xbmc.LOGERROR
        )


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def update_broadcasts():

    broadcasts = parse_sportschau()

    save_json(broadcasts)

    xbmc.log(
        f"[WM2026] {len(broadcasts)} "
        f"Broadcast Einträge erstellt",
        xbmc.LOGINFO
    )