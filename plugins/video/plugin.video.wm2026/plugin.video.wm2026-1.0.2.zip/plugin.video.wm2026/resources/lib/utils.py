# -*- coding: utf-8 -*-

import datetime


# ------------------------------------------------------------------
# Match-Zeit erzeugen
# ------------------------------------------------------------------
def get_match_datetime(date_str, time_str):

    try:

        # Beispiel:
        # 13:00 UTC-6

        time_part, utc_part = time_str.split(" UTC")

        hour, minute = map(int, time_part.split(":"))

        utc_offset = int(utc_part)

        # Matchzeit erzeugen
        match_datetime = datetime.datetime(
            int(date_str[0:4]),
            int(date_str[5:7]),
            int(date_str[8:10]),
            hour,
            minute
        )

        # UTC korrigieren
        utc_datetime = match_datetime - datetime.timedelta(
            hours=utc_offset
        )

        # Deutschland Sommerzeit
        local_datetime = utc_datetime + datetime.timedelta(
            hours=2
        )

        return local_datetime

    except Exception:

        return None


# ------------------------------------------------------------------
# UTC Zeit in lokale Zeit umwandeln
# ------------------------------------------------------------------
def convert_to_local_time(date_str, time_str):

    local_datetime = get_match_datetime(
        date_str,
        time_str
    )

    if not local_datetime:

        return f"{date_str} | {time_str}"

    weekdays = [
        "Mo",
        "Di",
        "Mi",
        "Do",
        "Fr",
        "Sa",
        "So"
    ]

    weekday = weekdays[
        local_datetime.weekday()
    ]

    return (
        f"{weekday}. "
        f"{local_datetime.strftime('%d.%m. | %H:%M Uhr')}"
    )


# ------------------------------------------------------------------
# LIVE Prüfung
# ------------------------------------------------------------------
def is_match_live(date_str, time_str):

    match_datetime = get_match_datetime(
        date_str,
        time_str
    )

    if not match_datetime:

        return False

    now = datetime.datetime.utcnow() + datetime.timedelta(
        hours=2
    )

    end_time = match_datetime + datetime.timedelta(
        hours=2
    )

    return match_datetime <= now <= end_time