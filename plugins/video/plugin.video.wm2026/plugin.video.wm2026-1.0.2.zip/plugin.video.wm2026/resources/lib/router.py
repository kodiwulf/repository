# -*- coding: utf-8 -*-

import sys

from urllib.parse import (
    urlencode,
    parse_qsl
)

import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs

from resources.lib.matches import (
    get_matches,
    get_today_matches,
    get_live_matches,
    get_germany_matches,
    get_groups,
    get_matches_by_group,
    get_round_of_16_matches,
    get_quarter_final_matches,
    get_semi_final_matches,
    get_third_place_matches,
    get_final_matches
)

from resources.lib.playback import play_stream
from resources.lib.utils import convert_to_local_time


ADDON = xbmcaddon.Addon(
    id="plugin.video.wm2026"
)

ADDON_ICON = xbmcvfs.translatePath(
    ADDON.getAddonInfo("icon")
)

ADDON_FANART = xbmcvfs.translatePath(
    ADDON.getAddonInfo("fanart")
)


class Router:

    def __init__(self, argv):

        self.base_url = argv[0]

        self.handle = int(argv[1])

        self.params = dict(
            parse_qsl(argv[2][1:])
        )

    # ------------------------------------------------------------------
    # Router Start
    # ------------------------------------------------------------------
    def run(self):

        action = self.params.get(
            "action"
        )

        # --------------------------------------------------------------
        # Playback
        # --------------------------------------------------------------
        if action == "play":

            self.play_match()

        # --------------------------------------------------------------
        # LIVE
        # --------------------------------------------------------------
        elif action == "live":

            self.show_matches(
                get_live_matches(),
                "Aktuell keine Live-Spiele verfügbar"
            )

        # --------------------------------------------------------------
        # Heute
        # --------------------------------------------------------------
        elif action == "today":

            self.show_matches(
                get_today_matches(),
                "Heute keine Spiele verfügbar"
            )

        # --------------------------------------------------------------
        # Deutschland
        # --------------------------------------------------------------
        elif action == "germany":

            self.show_matches(
                get_germany_matches(),
                "Keine Deutschland Spiele verfügbar"
            )

        # --------------------------------------------------------------
        # Gruppenphase
        # --------------------------------------------------------------
        elif action == "groups":

            self.show_groups()

        elif action == "group_matches":

            group_name = self.params.get(
                "group",
                ""
            )

            self.show_matches(
                get_matches_by_group(group_name),
                "Keine Gruppenspiele verfügbar"
            )

        # --------------------------------------------------------------
        # KO Phase
        # --------------------------------------------------------------
        elif action == "round16":

            self.show_matches(
                get_round_of_16_matches(),
                "Keine Achtelfinalspiele verfügbar"
            )

        elif action == "quarterfinals":

            self.show_matches(
                get_quarter_final_matches(),
                "Keine Viertelfinalspiele verfügbar"
            )

        elif action == "semifinals":

            self.show_matches(
                get_semi_final_matches(),
                "Keine Halbfinalspiele verfügbar"
            )

        elif action == "thirdplace":

            self.show_matches(
                get_third_place_matches(),
                "Kein Spiel um Platz 3 verfügbar"
            )

        elif action == "final":

            self.show_matches(
                get_final_matches(),
                "Kein Finale verfügbar"
            )

        # --------------------------------------------------------------
        # Alle Spiele
        # --------------------------------------------------------------
        elif action == "all":

            self.show_matches(
                get_matches()
            )

        # --------------------------------------------------------------
        # Hauptmenü
        # --------------------------------------------------------------
        else:

            self.show_main_menu()

    # ------------------------------------------------------------------
    # Hauptmenü
    # ------------------------------------------------------------------
    def show_main_menu(self):

        xbmcplugin.setContent(
            self.handle,
            "videos"
        )

        self.add_directory_item(
            "Live Jetzt",
            "live"
        )

        self.add_directory_item(
            "Heute",
            "today"
        )

        self.add_directory_item(
            "Deutschland",
            "germany"
        )

        self.add_directory_item(
            "Gruppenphase",
            "groups"
        )

        self.add_directory_item(
            "Achtelfinale",
            "round16"
        )

        self.add_directory_item(
            "Viertelfinale",
            "quarterfinals"
        )

        self.add_directory_item(
            "Halbfinale",
            "semifinals"
        )

        self.add_directory_item(
            "Spiel um Platz 3",
            "thirdplace"
        )

        self.add_directory_item(
            "Finale",
            "final"
        )

        self.add_directory_item(
            "Alle Spiele",
            "all"
        )

        xbmcplugin.endOfDirectory(
            self.handle,
            cacheToDisc=False
        )

    # ------------------------------------------------------------------
    # Gruppen anzeigen
    # ------------------------------------------------------------------
    def show_groups(self):

        xbmcplugin.setContent(
            self.handle,
            "videos"
        )

        groups = get_groups()

        for group in groups:

            url = self.build_url({

                "action": "group_matches",

                "group": group

            })

            list_item = xbmcgui.ListItem(
                label=group
            )

            list_item.setArt({

                "icon": ADDON_ICON,

                "thumb": ADDON_ICON,

                "fanart": ADDON_FANART

            })

            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )

        xbmcplugin.endOfDirectory(
            self.handle,
            cacheToDisc=False
        )

    # ------------------------------------------------------------------
    # Kategorien
    # ------------------------------------------------------------------
    def add_directory_item(self, title, action):

        url = self.build_url({
            "action": action
        })

        list_item = xbmcgui.ListItem(
            label=title
        )

        list_item.setArt({

            "icon": ADDON_ICON,

            "thumb": ADDON_ICON,

            "fanart": ADDON_FANART

        })

        xbmcplugin.addDirectoryItem(
            handle=self.handle,
            url=url,
            listitem=list_item,
            isFolder=True
        )

    # ------------------------------------------------------------------
    # Matchliste
    # ------------------------------------------------------------------
    def show_matches(self, matches, empty_message=None):

        xbmcplugin.setContent(
            self.handle,
            "videos"
        )

        xbmcplugin.addSortMethod(
            self.handle,
            xbmcplugin.SORT_METHOD_UNSORTED
        )

        # --------------------------------------------------------------
        # Keine Spiele
        # --------------------------------------------------------------
        if not matches:

            if empty_message:

                list_item = xbmcgui.ListItem(
                    label=empty_message
                )

                list_item.setArt({

                    "icon": ADDON_ICON,

                    "thumb": ADDON_ICON,

                    "fanart": ADDON_FANART

                })

                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url="",
                    listitem=list_item,
                    isFolder=False
                )

            xbmcplugin.endOfDirectory(
                self.handle,
                cacheToDisc=False
            )

            return

        # --------------------------------------------------------------
        # Spiele anzeigen
        # --------------------------------------------------------------
        for match in matches:

            self.add_match_item(match)

        xbmcplugin.endOfDirectory(
            self.handle,
            cacheToDisc=False
        )

    # ------------------------------------------------------------------
    # Spiel-Eintrag
    # ------------------------------------------------------------------
    def add_match_item(self, match):

        local_time = convert_to_local_time(
            match["date"],
            match["time"]
        )

        playable = match.get(
            "playable",
            False
        )

        channel = match.get(
            "channel",
            "Magenta"
        )

        is_result = match.get(
            "is_result",
            False
        )
		
        is_finished = match.get(
            "is_finished",
            False
        )		

        group_or_round = (
            match.get("group")
            or
            match.get("round")
            or
            "Unbekannt"
        )

        # --------------------------------------------------------------
        # LIVE Anzeige
        # --------------------------------------------------------------
        live_prefix = ""

        if match["live"]:

            live_prefix = "[B][LIVE][/B] "

        # --------------------------------------------------------------
        # Abgeschlossene Spiele normal darstellen
        # --------------------------------------------------------------
        if playable or is_finished:

            match_title = (
                f"{match['home']} vs "
                f"{match['away']}"
            )

        else:

            match_title = (
                f"[COLOR gray]"
                f"{match['home']} vs "
                f"{match['away']}"
                f"[/COLOR]"
            )

        if is_result:

            title = (
                f"{local_time} | "
                f"{live_prefix}"
                f"{match_title} | "
                f"{channel}"
            )

        elif is_finished:

            title = (
                f"{local_time} | "
                f"{live_prefix}"
                f"{match_title}"
            )

        else:

            title = (
                f"{local_time} | "
                f"{live_prefix}"
                f"{match_title}"
            )

        # --------------------------------------------------------------
        # Plot
        # --------------------------------------------------------------
        if is_result:

            plot = (
                f"Stadion: "
                f"{match['stadium']}\n"

                f"Ort: "
                f"{match['city']}\n"

                f"Kapazität: "
                f"{match['capacity']:,}".replace(",", ".")
                + "\n"

                f"Gruppe/Runde: "
                f"{group_or_round}\n\n"

                f"Endergebnis: "
                f"{channel}"
            )

        elif playable:

            plot = (
                f"Stadion: "
                f"{match['stadium']}\n"

                f"Ort: "
                f"{match['city']}\n"

                f"Kapazität: "
                f"{match['capacity']:,}".replace(",", ".")
                + "\n"

                f"Gruppe/Runde: "
                f"{group_or_round}\n"

                f"Sender: "
                f"{channel}"
            )

        else:

            plot = (
                f"Stadion: "
                f"{match['stadium']}\n"

                f"Ort: "
                f"{match['city']}\n"

                f"Kapazität: "
                f"{match['capacity']:,}".replace(",", ".")
                + "\n"

                f"Gruppe/Runde: "
                f"{group_or_round}\n\n"

                f"Exklusiv verfügbar bei:\n"
                f"MagentaTV"
            )

        # --------------------------------------------------------------
        # Senderlogo
        # --------------------------------------------------------------
        icon = ADDON_ICON

        if channel == "ARD":

            icon = (
                "special://home/addons/"
                "plugin.video.wm2026/"
                "resources/media/ard.png"
            )

        elif channel == "ZDF":

            icon = (
                "special://home/addons/"
                "plugin.video.wm2026/"
                "resources/media/zdf.png"
            )

        elif channel == "Magenta":

            icon = (
                "special://home/addons/"
                "plugin.video.wm2026/"
                "resources/media/magenta.png"
            )

        # --------------------------------------------------------------
        # ListItem
        # --------------------------------------------------------------
        list_item = xbmcgui.ListItem(
            label=title
        )

        list_item.setInfo("video", {

            "title": title,

            "plot": plot

        })

        list_item.setArt({

            "icon": icon,

            "thumb": icon,

            "fanart": ADDON_FANART

        })

        # --------------------------------------------------------------
        # Nur spielbare Spiele abspielbar
        # --------------------------------------------------------------
        if playable:

            list_item.setProperty(
                "IsPlayable",
                "true"
            )

            # ----------------------------------------------------------
            # Playback URL
            # ----------------------------------------------------------
            url = self.build_url({

                "action": "play",

                "stream": channel

            })

            is_folder = False

        else:

            url = ""

            is_folder = False

        xbmcplugin.addDirectoryItem(
            handle=self.handle,
            url=url,
            listitem=list_item,
            isFolder=is_folder
        )

    # ------------------------------------------------------------------
    # Playback
    # ------------------------------------------------------------------
    def play_match(self):

        channel = self.params.get(
            "stream"
        )

        play_stream(
            self.handle,
            channel
        )

    # ------------------------------------------------------------------
    # URL Builder
    # ------------------------------------------------------------------
    def build_url(self, query):

        return (
            f"{self.base_url}?"
            f"{urlencode(query)}"
        )