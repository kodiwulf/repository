# STBplus - Advanced IPTV Kodi Addon

 
**Kompatibilität:** Kodi 21+ (Omega)  
**Protokoll:** Stalker Portal API

## Features Übersicht

### 📺 Live TV
- **Channel Zapping**: Schnelles Kanalwechseln mit Touch, Tastatur oder Fernbedienung
- **EPG Support**: Electronic Program Guide mit aktuellen Sendungsinformationen  
- **Touch Controls**: Overlay mit Previous/Stop/Next Buttons für Touchscreens
- **Country Groups**: Automatische Länder-Filterung der Kanäle
- **Favorites**: Persönliche Lieblings-Kanäle speichern

### 🎬 Movies (VOD)
- **Kategorien**: Sortierung nach Genres und Jahren
- **Search**: Durchsuchen der Filme-Bibliothek
- **Download**: Filme herunterladen mit Fortschrittsanzeige
- **Favorites**: Lieblings-Filme markieren
- **Premium Countries**: Länderspezifische Premium-Inhalte

### 📺 TV Serien
- **Staffel-Navigation**: Übersichtliche Darstellung von Staffeln und Episoden
- **Auto-Play**: Automatische Wiedergabe der nächsten Episode
- **Download**: Serien-Episoden herunterladen
- **Favorites**: Lieblings-Serien speichern
- **Resume**: Wiedergabe ab letzter Position

### 🔧 Portal Manager
- **Multi-Portal**: Mehrere IPTV Portals gleichzeitig verwalten
- **Auto-Switch**: Automatischer Wechsel bei Portal-Ausfällen
- **Portal Testing**: Verbindung und Verfügbarkeit testen
- **Manual/Random**: Manuelle oder zufällige Portal-Auswahl

---

## Installation & Setup

### 1. Addon Installation
1. STBplus ZIP-Datei herunterladen
2. Kodi ↄ1�7 Addons ↄ1�7 Aus ZIP-Datei installieren
3. STBplus ZIP-Datei auswählen
4. Installation abwarten

### 2. Basic Setup (Einzelnes Portal)
1. **Addon Settings** öffnen
2. **Portal Configuration**:
   - `Use Online List`: **DEAKTIVIERT** lassen
   - `Portal Manager`: **DEAKTIVIERT** lassen
3. **Manual Configuration**:
   - `Server`: Portal URL eingeben (z.B. `http://server.com:8080`)
   - `MAC Address`: MAC-Adresse eingeben (12 Zeichen, z.B. `00:1A:79:XX:XX:XX`)

### 3. Portal Manager Setup (Multi-Portal)
1. **Addon Settings** ↄ1�7 **Portal Configuration**:
   - `Use Online List`: **DEAKTIVIERT**
   - `Portal Manager`: **AKTIVIERT**
2. **Portal Manager** im Hauptmenü öffnen
3. **Portal hinzufügen**:
   - Name eingeben (z.B. "Main Server")
   - URL eingeben
   - MAC-Adresse eingeben
   - Beschreibung (optional)
4. **Portal aktivieren** und testen

---

## Hauptmenü Navigation

### 📺 Live TV
**Zugriff**: Hauptmenü ↄ1�7 Live TV

#### Channel Navigation
- **Browse**: Kategorien durchstöbern
- **Countries**: Nach Ländern filtern
- **Favorites**: Lieblings-Kanäle anzeigen
- **Search**: Kanäle suchen

#### Live TV Playback
**Zapping Controls** (nur bei Live TV):
- **Tastatur**: `ↄ1�7/↓` für Channel +/-
- **Remote**: `CH+/CH-` Tasten
- **Touch**: Swipe Up/Down oder Touch-Overlay
- **Overlay**: Previous/Stop/Next Buttons

#### EPG (Electronic Program Guide)
**Aktivierung**: Settings ↄ1�7 EPG ↄ1�7 Enable EPG
- Sendungsinformationen in Channel-Listen
- Aktuelle und kommende Sendungen
- Cache-Zeit konfigurierbar (Standard: 6h)

### 🎬 Movies (Filme)
**Zugriff**: Hauptmenü ↄ1�7 Filme

#### Navigation
- **Kategorien**: Nach Genre durchstöbern  
- **Countries**: Premium-Inhalte nach Ländern
- **Favorites**: Lieblings-Filme
- **Search**: Filme suchen

#### Movie Playback
- **Play**: Standard Kodi Player (kein Zapping)
- **Download**: Film herunterladen
- **Add to Favorites**: Zu Favoriten hinzufügen

#### Download Feature
1. **Film auswählen** ↄ1�7 Kontextmenü ↄ1�7 Download
2. **Download-Modus wählen**:
   - Mit Fortschrittsanzeige (interaktiv)
   - Im Hintergrund (silent)
3. **Speicherort**: Automatisch nach Typ organisiert
4. **Resume Support**: Unterbrochene Downloads fortsetzen

### 📺 TV Serien
**Zugriff**: Hauptmenü ↄ1�7 Serien

#### Navigation
- **Kategorien**: Nach Genre sortiert
- **Seasons**: Staffel-Übersicht
- **Episodes**: Episoden-Liste mit Details
- **Next Episode**: Auto-Navigation zur nächsten Episode

#### Series Playback  
- **Standard Player**: Normaler Kodi Player (kein Zapping)
- **Auto-Play**: Nächste Episode automatisch
- **Resume**: Wiedergabe fortsetzen
- **Download**: Einzelne Episoden herunterladen

---

## Portal Manager (Multi-Portal Support)

### Portal Manager Aktivieren
**Requirements**:
- `Use Online List` = **DEAKTIVIERT**
- `Portal Manager` = **AKTIVIERT**

### Portal Hinzufügen
1. **Hauptmenü** ↄ1�7 Portal Manager
2. **Add Portal** wählen
3. **Portal Details eingeben**:
   - **Name**: Beschreibender Name (z.B. "Server 1")
   - **URL**: Vollständige Portal-URL
   - **MAC**: MAC-Adresse für dieses Portal  
   - **Description**: Optionale Beschreibung

### Portal Management
- **List Portals**: Alle konfigurierten Portals anzeigen
- **Test Portal**: Verbindung und Verfügbarkeit testen
- **Set Active**: Portal manuell aktivieren  
- **Remove Portal**: Portal löschen
- **Random Switch**: Zufälliges Portal auswählen

### Auto-Switching
- Automatischer Wechsel bei Portal-Ausfällen
- Intelligent Fallback auf verfügbare Portals
- Transparenter Wechsel ohne Unterbrechung

---

## Advanced Features

### Country Groups Filter
**Aktivierung**: Settings ↄ1�7 Country Groups ↄ1�7 Enable

#### Funktionsweise
- **Automatische Erkennung**: Kanalname-basierte Länder-Zuordnung
- **Gruppen-Filter**: Kanäle nach Ländern gruppiert
- **Custom Groups**: Eigene Länder-Kombinationen
- **Unknown Channels**: Unbekannte Kanäle ein-/ausblenden

#### Configuration
- `country_groups_enable`: Feature aktivieren
- `country_groups_extra`: Zusätzliche Länder-Codes
- `country_groups_allow_unknown`: Unbekannte Kanäle anzeigen

### Favorites System
**Unterstützt**: Live TV, Movies, Series

#### Verwaltung
- **Hinzufügen**: Kontextmenü ↄ1�7 "Add to STB Favorites"
- **Entfernen**: Kontextmenü ↄ1�7 "Remove from STB Favorites"  
- **Anzeigen**: Hauptkategorie ↄ1�7 "Favorites"

### Search Functions
**Verfügbar für**: Live TV, Movies, Series

#### Nutzung
1. **Kategorie wählen** (TV/Movies/Series)
2. **Search Option** auswählen  
3. **Suchbegriff eingeben**
4. **Ergebnisse durchstöbern**

### Cache Management
**Zugriff**: Hauptmenü ↄ1�7 Cache leeren

#### Funktionen
- **Clear Cache**: Alle Cache-Daten löschen
- **System Refresh**: Komplette Aktualisierung
- **Auto-Cache**: Intelligente Cache-Verwaltung

---

## Touch Controls (Live TV Only)

### Activation
**Automatisch aktiv** bei Live TV Playback

### Touch Overlay
**3-Zonen Layout**:
- **Links**: Previous Channel
- **Mitte**: Stop/Close
- **Rechts**: Next Channel

### Gesture Controls
- **Swipe Up/Down**: Channel +/-
- **Swipe Left**: Next Channel  
- **Swipe Right**: Previous Channel
- **Double Tap**: Portal Switch (wenn verfügbar)

### Settings
- Overlay automatisch bei Live TV
- Transparente Button-Darstellung
- Konfigurierbare Gesten

---

## Keyboard Shortcuts (Live TV)

### Zapping Controls
- **ↄ1�7 (Up)**: Next Channel
- **ↄ1�7 (Down)**: Previous Channel
- **CH+ (Remote)**: Next Channel
- **CH- (Remote)**: Previous Channel

### Portal Controls  
- **P**: Portal Switch (Multi-Portal)
- **I**: Portal Info anzeigen
- **R**: System Refresh

---

## Settings Guide

### Portal Configuration
- **Use Online List**: Externe Portal-Liste verwenden
- **Online URL**: URL der Portal-Liste  
- **Portal Manager**: Multi-Portal Support aktivieren
- **Server**: Manual Portal URL
- **MAC Address**: MAC für Manual Portal

### Device Configuration
- **Serial Number**: STB Seriennummer
- **Device ID**: Eindeutige Geräte-ID
- **Device ID 2**: Zusätzliche Device-ID  
- **Signature**: Portal-spezifische Signatur

### EPG Settings
- **Enable EPG**: Electronic Program Guide aktivieren
- **EPG Cache Hours**: Cache-Dauer (Standard: 6h)
- **EPG Period Days**: EPG-Zeitraum (Standard: 2 Tage)
- **EPG Lines**: Anzahl EPG-Zeilen in Listen
- **Append to Name**: EPG-Info an Kanalnamen anhängen

### Country Groups
- **Enable**: Country Groups Filter aktivieren
- **Extra Countries**: Zusätzliche Länder-Codes
- **Allow Unknown**: Unbekannte Kanäle anzeigen

