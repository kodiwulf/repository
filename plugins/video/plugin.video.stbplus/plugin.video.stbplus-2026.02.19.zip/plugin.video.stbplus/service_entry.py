# -*- coding: utf-8 -*-

from lib.loggers import Logger
if __name__ == '__main__':
    from lib.service import run

    run()