# -*- coding: utf-8 -*-
import sys, json, os, xbmc, xbmcgui, xbmcaddon

ADDON_ID = 'plugin.video.stbplus'
ZAP_FILE = os.path.join(
    xbmc.translatePath('special://profile/addon_data/' + ADDON_ID),
    'z.json'
)

def load():
    try:
        with open(ZAP_FILE) as f:
            d = json.load(f)
            return d.get('c', []), d.get('i', 0)
    except:
        return [], 0

def save_index(i):
    try:
        with open(ZAP_FILE) as f: d = json.load(f)
        d['i'] = i
        with open(ZAP_FILE, 'w') as f: json.dump(d, f)
    except: pass

if xbmc.Player().isPlayingVideo():
    direction = sys.argv[1] if len(sys.argv) > 1 else 'n'
    ch, idx = load()
    if not ch:
        xbmc.log('[Zap] Keine Kanäle', xbmc.LOGINFO)
        sys.exit(0)
    idx = (idx + 1) % len(ch) if direction == 'n' else (idx - 1) % len(ch)
    save_index(idx)
    c = ch[idx]
    xbmc.log(f"[Zap] -> {c['name']} ({idx+1}/{len(ch)})", xbmc.LOGINFO)
    
    xbmc.executebuiltin(f"RunAddon({ADDON_ID},?action=tv_play&cmd={c['cmd']}&_zap=1)")