# -*- coding: utf-8 -*-
# Python 3

import xbmc
import xbmcgui
import time
from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from xbmc import LOGINFO as LOGNOTICE, LOGERROR, log
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from resources.lib.tools import logger, cParser, cCache

try:
    import resolveurl as resolver
except ImportError:
    xbmcgui.Dialog().ok(cConfig().getLocalizedString(30119), cConfig().getLocalizedString(30120))


def viewInfo(params):
    from resources.lib.tmdbinfo import WindowsBoxes
    parms = ParameterHandler()
    sCleanTitle = params.getValue('searchTitle')
    sMeta = parms.getValue('sMeta')
    sYear = parms.getValue('sYear')
    WindowsBoxes(sCleanTitle, sCleanTitle, sMeta, sYear)


def parseUrl():
    params = ParameterHandler()
    logger.info(params.getAllParameters())

    # If no function is set, we set it to the default "load" function
    if params.exist('function'):
        sFunction = params.getValue('function')
        if sFunction == 'spacer':
            return True
        elif sFunction == 'clearCache':
            cRequestHandler('dummy').clearCache()
            return
        elif sFunction == 'viewInfo':
            viewInfo(params)
            return
        elif sFunction == 'devUpdates':
            from resources.lib import updateManager
            updateManager.devUpdates()
            return
        elif sFunction == 'searchAlter':
            searchAlter(params)
            return
        elif sFunction == 'searchTMDB':
            searchTMDB(params)
            return
        elif sFunction == 'openSettings':
            cConfig().showSettingsWindow()
            cGui().setEndOfDirectory(False)
            return

    elif params.exist('remoteplayurl'):
        try:
            remotePlayUrl = params.getValue('remoteplayurl')
            sLink = resolver.resolve(remotePlayUrl)
            if sLink:
                xbmc.executebuiltin('PlayMedia(' + sLink + ')')
            else:
                log(cConfig().getLocalizedString(30166) + ' -> [serienstream]: Could not play remote url %s ' % sLink, LOGNOTICE)
        except resolver.resolver.ResolverError as e:
            log(cConfig().getLocalizedString(30166) + ' -> [serienstream]: ResolverError: %s' % e, LOGERROR)
        return
    else:
        sFunction = 'load'

    # Test if we should run a function on a special site
    if not params.exist('site'):
        # No site specified → load SerienStream directly as main menu
        showMainMenu(sFunction)
        return

    sSiteName = params.getValue('site')

    if params.exist('playMode'):
        from resources.lib.gui.hoster import cHosterGui
        url = False
        playMode = params.getValue('playMode')
        isHoster = params.getValue('isHoster')
        url = params.getValue('url')
        manual = params.exist('manual')

        if cConfig().getSetting('hosterSelect') == 'Auto' and playMode != 'jd' and playMode != 'jd2' and not manual:
            cHosterGui().streamAuto(playMode, sSiteName, sFunction)
        else:
            cHosterGui().stream(playMode, sSiteName, sFunction, url)
        return

    log(cConfig().getLocalizedString(30166) + " -> [serienstream]: Call function '%s' from '%s'" % (sFunction, sSiteName), LOGNOTICE)

    # If the hoster gui is called, run the function on it and return
    if sSiteName == 'cHosterGui':
        showHosterGui(sFunction)
    # Settings
    elif sSiteName == 'serienstream_settings':
        cGui.openSettings()
    # Resolver Settings
    elif sSiteName == 'resolver':
        oGui = cGui()
        resolver.display_settings()
        oGui.setEndOfDirectory()
        xbmc.executebuiltin('Action(ParentDir)')
    # Manual Update
    elif sSiteName == 'devUpdates':
        from resources.lib import updateManager
        updateManager.devUpdates()
    else:
        # Load serienstream site plugin
        plugin = __import__(sSiteName, globals(), locals())
        function = getattr(plugin, sFunction)
        function()


def showMainMenu(sFunction):
    """Show main menu with site entry and settings."""
    from resources.lib.gui.guiElement import cGuiElement
    from resources.lib.handler.ParameterHandler import ParameterHandler

    addon_id = cConfig().getAddonInfo('id')
    start_time = time.time()

    # Wait for startup status check (max 10 seconds)
    while (startupStatus := cCache().get(addon_id + '_main', -1)) != 'finished' and time.time() - start_time <= 5:
        time.sleep(0.2)

    oGui = cGui()
    params = ParameterHandler()

    # SerienStream
    params.setParam('site', 'serienstream')
    params.setParam('function', 'load')
    oGui.addFolder(cGuiElement('SerienStream', 'serienstream', 'load'), params)

    # Einstellungen / Settings
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30041), 'serienstream', 'openSettings'))

    oGui.setEndOfDirectory()




def searchAlter(params):
    """Search for alternative sources - simplified for standalone addon."""
    import serienstream as plugin
    
    searchTitle = params.getValue('searchTitle')
    searchImdbId = params.getValue('searchImdbID')
    searchYear = params.getValue('searchYear')
    
    if not searchTitle:
        return
    
    # Extract year from title
    if ' (19' in searchTitle or ' (20' in searchTitle:
        isMatch, aYear = cParser.parse(searchTitle, r'(.*?) \((\d{4})\)')
        if isMatch:
            searchTitle = aYear[0][0]
            if not searchYear:
                searchYear = str(aYear[0][1])
    
    # Remove season/episode markers
    for token in [' S0', ' E0', ' - Staffel', ' Staffel']:
        if token in searchTitle:
            searchTitle = searchTitle.split(token)[0].strip()
            break
    
    oGui = cGui()
    oGui.globalSearch = True
    oGui._collectMode = True
    
    try:
        function = getattr(plugin, '_search')
        function(oGui, searchTitle)
    except Exception as e:
        log(cConfig().getLocalizedString(30166) + ' -> [serienstream]: searchAlter failed: %s' % str(e), LOGERROR)
    
    # Filter results
    oGui._collectMode = False
    total = len(oGui.searchResults)
    for result in oGui.searchResults:
        guiElement = result['guiElement']
        if searchTitle.lower() not in guiElement.getTitle().lower():
            continue
        if guiElement._sYear and searchYear and guiElement._sYear != searchYear:
            continue
        oGui.addFolder(result['guiElement'], result['params'], bIsFolder=result['isFolder'], iTotal=total)
    
    oGui.setView()
    oGui.setEndOfDirectory()


def searchTMDB(params):
    """Search triggered by TMDB Helper - simplified for standalone addon."""
    import serienstream as plugin
    
    sSearchText = params.getValue('searchTitle')
    if not sSearchText:
        cGui().setEndOfDirectory()
        return
    
    oGui = cGui()
    oGui.globalSearch = True
    oGui._collectMode = True
    
    try:
        function = getattr(plugin, '_search')
        function(oGui, sSearchText)
    except Exception as e:
        log(cConfig().getLocalizedString(30166) + ' -> [serienstream]: searchTMDB failed: %s' % str(e), LOGERROR)
    
    oGui._collectMode = False
    total = len(oGui.searchResults)
    for result in sorted(oGui.searchResults, key=lambda k: k['guiElement'].getTitle()):
        oGui.addFolder(result['guiElement'], result['params'], bIsFolder=result['isFolder'], iTotal=total)
    
    oGui.setView()
    oGui.setEndOfDirectory()


def showHosterGui(sFunction):
    from resources.lib.gui.hoster import cHosterGui
    oHosterGui = cHosterGui()
    function = getattr(oHosterGui, sFunction)
    function()
    return True
