# -*- coding: utf-8 -*-
# Python 3

import os
import xbmc
import time

from resources.lib.config import cConfig
from resources.lib import tools
from xbmc import LOGERROR, LOGDEBUG, log
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib import updateManager
from resources.lib.utils import translatePath
from resources.lib.tools import cCache
from resources.lib.tools import infoDialog

# ResolverUrl Addon Data
RESOLVE_ADDON_DATA_PATH = translatePath(os.path.join('special://home/userdata/addon_data/script.module.resolveurl'))
RESOLVE_SHA = os.path.join(translatePath(RESOLVE_ADDON_DATA_PATH), "update_sha")
ADDON_PATH = translatePath(os.path.join('special://home/addons/', '%s'))


def delHtmlCache():
    deltaDay = int(cConfig().getSetting('cacheDeltaDay', 2))
    deltaTime = 60 * 60 * 24 * deltaDay
    currentTime = int(time.time())
    if currentTime >= int(cConfig().getSetting('lastdelhtml', 0)) + deltaTime:
        cRequestHandler('').clearCache()
        cConfig().setSetting('lastdelhtml', str(currentTime))


def _shouldDoResolverUpdate():
    """Check if this addon should handle the resolver update.
    Priority: xStream > AniWorld > SerienStream.
    Only one addon should update the resolver to avoid conflicts."""
    from xbmc import LOGINFO as LOGNOTICE
    LOGMSG = cConfig().getLocalizedString(30166)

    # If xStream is installed, let xStream handle resolver updates
    xstream_path = translatePath('special://home/addons/plugin.video.xstream')
    if os.path.isdir(xstream_path):
        log(LOGMSG + ' -> [service]: xStream detected, skipping resolver update (handled by xStream)', LOGNOTICE)
        return False

    # If SerienStream is also installed, AniWorld takes priority
    serienstream_path = translatePath('special://home/addons/plugin.video.serienstream')
    if os.path.isdir(serienstream_path):
        log(LOGMSG + ' -> [service]: SerienStream also installed, AniWorld handles resolver update', LOGNOTICE)

    return True


def main():
    cCache().set(cConfig().getAddonInfo('id') + '_main', 'running')

    # Resolver Update (only if no higher-priority addon handles it)
    if _shouldDoResolverUpdate():
        if os.path.isfile(RESOLVE_SHA) == False or cConfig().getSetting('githubUpdateResolver') == 'true' or cConfig().getSetting('enforceUpdate') == 'true':
            status2 = updateManager.resolverUpdate(True)
            if cConfig().getSetting('update.notification') == 'full':
                infoDialog(cConfig().getLocalizedString(30112), sound=False, icon='INFO', time=10000)
                if status2 == True: infoDialog('Resolver ' + cConfig().getSetting('resolver.branch') + cConfig().getLocalizedString(30116), sound=False, icon='INFO', time=6000)
                if status2 == False: infoDialog(cConfig().getLocalizedString(30117), sound=True, icon='ERROR')
                if status2 == None: infoDialog(cConfig().getLocalizedString(30118), sound=False, icon='INFO', time=6000)
                if cConfig().getSetting('enforceUpdate') == 'true': cConfig().setSetting('enforceUpdate', 'false')
            else:
                if status2 == True: infoDialog('Resolver ' + cConfig().getSetting('resolver.branch') + cConfig().getLocalizedString(30116), sound=False, icon='INFO', time=6000)
                if status2 == False: infoDialog(cConfig().getLocalizedString(30117), sound=True, icon='ERROR')
                if cConfig().getSetting('enforceUpdate') == 'true': cConfig().setSetting('enforceUpdate', 'false')

    # AniWorld Domain Check
    _checkAniWorldDomain()

    # Startup finished
    cCache().set(cConfig().getAddonInfo('id') + '_main', 'finished')

    # Changelog Popup
    if cConfig().getSetting('popup.update.notification') == 'true':
        tools.changelog()

    # Html Cache cleanup
    delHtmlCache()


def _checkAniWorldDomain():
    """Check AniWorld domain availability on startup."""
    from xbmc import LOGINFO as LOGNOTICE
    provider = 'aniworld'
    
    if cConfig().getSetting('plugin_aniworld_checkDomain') != 'true':
        return
    
    domain = cConfig().getSetting('plugin_aniworld.domain', 'aniworld.to')
    if not domain:
        domain = 'aniworld.to'
    
    base_link = 'http://' + domain + '/'
    
    try:
        from urllib.parse import urlparse
        import socket
        oRequest = cRequestHandler(base_link, caching=False, ignoreErrors=True)
        oRequest.requestTimeout = 3
        socket.setdefaulttimeout(3)
        oRequest.request()
        status_code = int(oRequest.getStatus())
        cConfig().setSetting('plugin_aniworld_status', str(status_code))
        log(cConfig().getLocalizedString(30166) + ' -> [checkDomain]: AniWorld Status Code ' + str(status_code) + ' - ' + base_link, LOGNOTICE)

        if 403 <= status_code <= 503:
            log(cConfig().getLocalizedString(30166) + ' -> [checkDomain]: AniWorld server error', LOGNOTICE)
        elif 300 <= status_code <= 400:
            url = oRequest.getRealUrl()
            cConfig().setSetting('plugin_aniworld.domain', urlparse(url).hostname)
            log(cConfig().getLocalizedString(30166) + ' -> [checkDomain]: AniWorld domain redirected', LOGNOTICE)
        elif status_code == 200:
            cConfig().setSetting('plugin_aniworld.domain', urlparse(base_link).hostname)
            log(cConfig().getLocalizedString(30166) + ' -> [checkDomain]: AniWorld domain OK', LOGNOTICE)
    except Exception as e:
        log(cConfig().getLocalizedString(30166) + ' -> [checkDomain]: AniWorld domain check error: %s' % str(e), LOGNOTICE)


if __name__ == "__main__":
    main()
