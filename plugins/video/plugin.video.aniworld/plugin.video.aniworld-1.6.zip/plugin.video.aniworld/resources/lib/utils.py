# -*- coding: utf-8 -*-
# Python 3

import os
import xbmcvfs
from xbmcvfs import translatePath
from resources.lib.config import cConfig

# # Todo - soll mal Hilfefunktion werden