# -*- coding: utf-8 -*-
"""
utils.py - Utility Functions Module

This module provides common utility functions used throughout the addon:
- Path handling and file system operations
- Caching (both in-memory and file-based)
- Authentication with Lokke API
- Kodi dialog helpers
- Plugin URL building and parameter handling
- Logging utilities

The caching system uses two layers:
1. Memory cache (Kodi home window properties) - fastest, lost on restart
2. File cache (JSON files in addon profile) - persistent across restarts
"""


import os
import sys
import time
import json
import uuid
import base64
import tempfile
import traceback
from datetime import datetime

import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin
import requests
from urllib.parse import urlencode, parse_qsl

# =============================================================================
# ADDON INITIALIZATION
# =============================================================================
# These are initialized once when the module is imported

addon = xbmcaddon.Addon()
addonInfo = addon.getAddonInfo
addonID = addonInfo('id')
addonprofile = xbmcvfs.translatePath(addonInfo('profile'))
cachepath = os.path.join(addonprofile, "cache")

# Home window for memory cache storage
# Window 10000 is the home window, properties persist during Kodi session
home = xbmcgui.Window(10000)

# =============================================================================
# CONSTANTS
# =============================================================================



# =============================================================================
# LOGGING
# =============================================================================

def _is_debug():
    """Check if debug logging is enabled."""
    return addon.getSetting("debug") == "true"


def log(msg, header="", force=False):
    """
    Log a message to Kodi's log file.
    
    Args:
        msg: Message to log (string, dict, or any object)
        header: Optional header/function name for context
        force: If True, always log at INFO level regardless of debug setting
    """
    try:
        if isinstance(msg, (dict, list)):
            msg = json.dumps(msg, indent=4, default=str)
        else:
            msg = str(msg)
    except (TypeError, ValueError):
        msg = str(msg)
    
    prefix = f"[{header}] " if header else ""
    output = f"####VavooTV#### {prefix}{msg}"
    
    if _is_debug() or force:
        xbmc.log(output, xbmc.LOGINFO)
    else:
        xbmc.log(output, xbmc.LOGDEBUG)


def log_debug(msg, header=""):
    """
    Log detailed debug information (only when debug is enabled).
    Includes timestamp and more verbose output.
    """
    if not _is_debug():
        return
    
    timestamp = time.strftime("%H:%M:%S")
    log(f"[{timestamp}] {msg}", header)


def log_exception(header=""):
    """
    Log the current exception with full traceback (only when debug is enabled).
    """
    if _is_debug():
        tb = traceback.format_exc()
        log(f"EXCEPTION:\n{tb}", header, force=True)


# =============================================================================
# CACHE DIRECTORY SETUP
# =============================================================================
if not os.path.exists(cachepath):
    os.makedirs(cachepath)
    log_debug(f"Created cache directory: {cachepath}", "init")


# =============================================================================
# CACHE MANAGEMENT
# =============================================================================

def _clear_expired_cache():
    """
    Remove expired cache files from disk.
    """
    try:
        removed_count = 0
        for filename in os.listdir(cachepath):
            filepath = os.path.join(cachepath, filename)

            if not os.path.isfile(filepath): 
                continue
            try:
                with open(filepath) as f:
                    data = json.load(f)
                expiry = data.get('sigValidUntil', 0)

                if expiry is not False and expiry < int(time.time()):
                    os.remove(filepath)
                    removed_count += 1
            except Exception: 
                pass
        if removed_count > 0:
            log_debug(f"Cleared {removed_count} expired cache files", "_clear_expired_cache")
    except OSError as e:
        log_debug(f"Error clearing cache: {e}", "_clear_expired_cache")


# Run cache cleanup on import
_clear_expired_cache()


# =============================================================================
# AUTHENTICATION
# =============================================================================
# Single auth system:
#   Lokke API (https://www.lokke.app/api/app/ping)
#   Returns "addonSig" used as mediahubmx-signature header.
# =============================================================================

AUTH_RETRIES = 3        # Number of retry attempts
AUTH_TTL = 1800         # Auth signature TTL in seconds (30 minutes)

# Window property keys — persist across plugin re-invocations within one Kodi session.
_AUTH_PROP_SIG = "vavootv_auth_sig"
_AUTH_PROP_TS  = "vavootv_auth_ts"


def _get_persistent_auth():
    """Read cached auth from Kodi window properties.
    Returns the signature only if it's younger than AUTH_TTL seconds.
    Expired tokens are cleared automatically."""
    sig = home.getProperty(_AUTH_PROP_SIG) or None
    ts  = home.getProperty(_AUTH_PROP_TS)  or None
    
    if not sig or not ts:
        return None
    
    try:
        age = int(time.time()) - int(ts)
    except (ValueError, TypeError):
        _clear_persistent_auth()
        return None
    
    if age >= AUTH_TTL:
        log_debug(f"Auth expired (age={age}s, TTL={AUTH_TTL}s), clearing", "_get_persistent_auth")
        _clear_persistent_auth()
        return None
    
    log_debug(f"Auth valid (age={age}s, TTL={AUTH_TTL}s)", "_get_persistent_auth")
    return sig


def _set_persistent_auth(signature):
    """Store auth signature with current timestamp in Kodi window properties."""
    home.setProperty(_AUTH_PROP_SIG, signature)
    home.setProperty(_AUTH_PROP_TS, str(int(time.time())))


def _clear_persistent_auth():
    """Clear persistent auth state."""
    home.clearProperty(_AUTH_PROP_SIG)
    home.clearProperty(_AUTH_PROP_TS)


_IDENTITY_FILE = os.path.join(addonprofile, "identity.json")


def _read_identity_file():
    """Read identity dict from file. Returns {} on any error."""
    try:
        if os.path.exists(_IDENTITY_FILE):
            with open(_IDENTITY_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return {}


def _write_identity_file(data):
    """Atomic write of identity dict to file."""
    try:
        if not os.path.exists(addonprofile):
            os.makedirs(addonprofile, exist_ok=True)
        # Atomic write via tempfile + replace
        fd, tmp_path = tempfile.mkstemp(dir=addonprofile, prefix="identity_", suffix=".tmp")
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(data, f)
            os.replace(tmp_path, _IDENTITY_FILE)
        except Exception:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
            raise
    except Exception as e:
        log(f"Failed to write identity file: {e}", "_write_identity_file", force=True)


def _get_persistent_device_id():
    """
    Get persistent device ID from identity.json. Generated once on first
    auth call and reused for all subsequent calls — behaves like a real
    Android device (stable ID per install).
    
    File-based storage is used because addon.setSetting() does not persist
    reliably across plugin invocations in Kodi 21+ (each plugin call is a
    fresh Python process).
    """
    data = _read_identity_file()
    device_id = data.get("device_id", "")
    
    if not device_id or len(device_id) != 16:
        device_id = uuid.uuid4().hex[:16]
        data["device_id"] = device_id
        _write_identity_file(data)
        log_debug(f"Generated new persistent device ID: {device_id}", "_get_persistent_device_id")
    
    return device_id


def _get_persistent_first_app_start():
    """
    Get persistent firstAppStart timestamp from identity.json. Generated
    once and reused — simulates a real install date that ages naturally
    over time (more realistic than always "24h ago").
    """
    data = _read_identity_file()
    stored = data.get("first_app_start")
    now_ms = int(time.time() * 1000)
    
    if isinstance(stored, int):
        # Sanity check: must not be in the future, must not be older than 10y
        if 0 < stored <= now_ms and (now_ms - stored) < 315360000000:
            return stored
    
    # Initial value: 24h ago (matches old behavior at install time)
    initial_ts = now_ms - 86400000
    data["first_app_start"] = initial_ts
    _write_identity_file(data)
    log_debug(f"Generated new persistent firstAppStart: {initial_ts}", "_get_persistent_first_app_start")
    return initial_ts


LOKKE_AUTH_URL = 'https://www.lokke.app/api/app/ping'


def _getLokkeAuthSignature():
    """
    Get authentication signature from Lokke API.
    Uses Android/okhttp user-agent matching the Lokke mobile app.
    Returns the addonSig string or None on failure.
    Silent operation — no UI dialogs during retries.
    """
    log_debug("Requesting Lokke auth signature...", "_getLokkeAuthSignature")
    
    headers = {
        "user-agent": "okhttp/4.11.0",
        "accept": "application/json",
        "content-type": "application/json; charset=utf-8",
        "accept-encoding": "gzip",
    }
    
    unique_id = _get_persistent_device_id()
    now_ms = int(time.time() * 1000)
    first_app_start = _get_persistent_first_app_start()
    
    data = {
        "token": "ldCvE092e7gER0rVIajfsXIvRhwlrAzP6_1oEJ4q6HH89QHt24v6NNL_jQJO219hiLOXF2hqEfsUuEWitEIGN4EaHHEHb7Cd7gojc5SQYRFzU3XWo_kMeryAUbcwWnQrnf0-",
        "reason": "app-blur",
        "locale": "de",
        "theme": "dark",
        "metadata": {
            "device": {
                "type": "TV",
                "brand": "NVIDIA",
                "model": "SHIELD Android TV",
                "name": "mdarcy",
                "uniqueId": unique_id
            },
            "os": {
                "name": "android",
                "version": "11",
                "abis": ["arm64-v8a"],
                "host": "android"
            },
            "app": {
                "platform": "android",
                "version": "1.1.0",
                "buildId": "97215000",
                "engine": "hbc85",
                "signatures": [
                    "6e8a975e3cbf07d5de823a760d4c2547f86c1403105020adee5de67ac510999e"
                ],
                "installer": "com.android.vending"
            },
            "version": {
                "package": "app.lokke.main",
                "binary": "1.1.0",
                "js": "1.1.0"
            },
            "platform": {
                "isAndroid": True,
                "isIOS": False,
                "isTV": True,
                "isWeb": False,
                "isMobile": False,
                "isWebTV": False,
                "isElectron": False
            }
        },
        "appFocusTime": 0,
        "playerActive": False,
        "playDuration": 0,
        "devMode": True,
        "hasAddon": True,
        "castConnected": False,
        "package": "app.lokke.main",
        "version": "1.1.0",
        "process": "app",
        "firstAppStart": first_app_start,
        "lastAppStart": now_ms,
        "ipLocation": None,
        "adblockEnabled": False,
        "proxy": {
            "supported": ["ss", "openvpn"],
            "engine": "openvpn",
            "ssVersion": 1,
            "enabled": False,
            "autoServer": True,
            "id": "fi-hel"
        },
        "iap": {"supported": True}
    }
    
    network_failures = 0  # Track timeouts / connection errors
    auth_failures = 0     # Track server responded but no addonSig
    
    for attempt in range(1, AUTH_RETRIES + 1):
        try:
            log_debug(f"POST {LOKKE_AUTH_URL} (attempt {attempt}/{AUTH_RETRIES})", "_getLokkeAuthSignature")
            response = requests.post(LOKKE_AUTH_URL, json=data, headers=headers, timeout=10)
            log_debug(f"Lokke response status: {response.status_code}", "_getLokkeAuthSignature")
            
            result = response.json()
            log_debug(f"Lokke ping response: {json.dumps(result, indent=2)}", "_getLokkeAuthSignature")
            
            signature = result.get("addonSig")
            if signature:
                log("Lokke auth signature obtained successfully", "_getLokkeAuthSignature", force=True)
                _log_signature_details(signature)
                return signature, None
            else:
                auth_failures += 1
                log(f"No addonSig in Lokke response (attempt {attempt}/{AUTH_RETRIES})", "_getLokkeAuthSignature", force=True)

        except Exception as e:
            network_failures += 1
            log(f"Lokke auth failed (attempt {attempt}/{AUTH_RETRIES}): {e}", "_getLokkeAuthSignature", force=True)
            log_exception("_getLokkeAuthSignature")
    
    # Determine failure reason: if ALL retries were network errors → server down
    # If any retry reached the server but got no sig → auth failed
    if auth_failures > 0:
        reason = "auth_failed"
        log("Lokke auth failed after all retries (server responded but no signature)", "_getLokkeAuthSignature", force=True)
    else:
        reason = "server_down"
        log("Lokke auth failed after all retries (server unreachable)", "_getLokkeAuthSignature", force=True)
    
    return None, reason


def _log_signature_details(signature):
    """Decode and log signature data for debugging."""
    try:
        sig_data = json.loads(base64.b64decode(signature + '=='))
        inner = json.loads(sig_data.get("data", "{}"))
        log(f"[Lokke] Auth status: status={inner.get('status')}, "
            f"verified={inner.get('verified')}, "
            f"app_ok={inner.get('app', {}).get('ok')}",
            "getAuthSignature", force=True)
    except Exception:
        pass


def getAuthSignature():
    """
    Get authentication signature with persistent caching.
    
    Uses Lokke API as the sole auth source.
    
    - Checks Kodi window properties first (persists across plugin invocations).
    - Silently retries on failure — only shows error dialog if all attempts fail.
    """
    # Return cached signature if available
    cached = _get_persistent_auth()
    if cached:
        log_debug("Using persistent auth", "getAuthSignature")
        return cached
    
    log_debug("No valid persistent auth, requesting fresh signature...", "getAuthSignature")
    
    try:
        signature, fail_reason = _getLokkeAuthSignature()
        
        if signature:
            _set_persistent_auth(signature)
            log("Auth obtained successfully", "getAuthSignature", force=True)
            return signature
        
        # Auth failed after all retries — show dialog matching the failure reason
        if fail_reason == "server_down":
            log("Server unreachable!", "getAuthSignature", force=True)
            error_dialog(
                "Server Is Down",
                "Could not reach the authentication server.\n"
                "Please check your connection or try again later.\n\n"
                "Press OK to return."
            )
        else:
            log("Authentication rejected!", "getAuthSignature", force=True)
            error_dialog(
                "Authentication Failed",
                "The server rejected the authentication request.\n"
                "The token may be expired or invalid.\n\n"
                "Press OK to return."
            )
        return None
    
    except Exception as e:
        log(f"Unexpected error during auth: {e}", "getAuthSignature", force=True)
        log_exception("getAuthSignature")
        return None


def refreshAuth():
    """
    Clear cached auth and request a fresh Lokke signature.
    Used by vjlive when a request fails and a fresh token might help.
    
    Returns new signature string or None if unavailable.
    """
    log("Refreshing Lokke auth...", "refreshAuth", force=True)
    _clear_persistent_auth()
    return getAuthSignature()

# =============================================================================
# DIALOG UTILITIES
# =============================================================================

def error_dialog(heading, message):
    """
    Show an error dialog that requires user to press OK.
    
    Args:
        heading: Dialog title
        message: Error message to display
    """
    log_debug(f"Showing error dialog: {heading} - {message}", "error_dialog")
    xbmcgui.Dialog().ok(heading, message)


def selectDialog(options, heading=None):
    """Show a selection dialog to the user."""
    if heading is None: 
        heading = addonInfo('name')

    log_debug(f"Selection dialog: {heading}, options={len(options)}", "selectDialog")

    result = xbmcgui.Dialog().select(str(heading), options)
    
    log_debug(f"Selection result: {result}", "selectDialog")
    return result
    

# =============================================================================
# CACHING SYSTEM
# =============================================================================



def set_cache(key, value, timeout=False):
    """
    Store a value in the cache.
    Uses atomic write (temp file + os.replace) for crash safety.
    """
    path = key
    log_debug(f"Setting cache: {path} (timeout={timeout}s)", "set_cache")
    
    expiry = False if timeout is False else int(time.time()) + timeout
    data = {"sigValidUntil": expiry, "value": value}
    json_str = json.dumps(data, indent=4)
    
    home.setProperty(path, json.dumps(data))
    
    filepath = os.path.join(cachepath, f"{path}.json")
    temp_path = None
    try:
        fd, temp_path = tempfile.mkstemp(dir=cachepath)
        with os.fdopen(fd, "w") as f:
            f.write(json_str)
        os.replace(temp_path, filepath)
        log_debug(f"Cache written to file: {filepath}", "set_cache")
    except Exception as e:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
        log(f"Failed to write cache: {e}", "set_cache")
        log_exception("set_cache")


def get_cache(key):
    """
    Retrieve a value from the cache.
    """
    path = key
    current_time = int(time.time())

    log_debug(f"Getting cache: {path}", "get_cache")
    
    # Try memory cache first
    cached = home.getProperty(path)
    if cached:
        try:
            data = json.loads(cached)
            expiry = data.get('sigValidUntil', 0)

            if expiry is False or expiry > current_time: 
                log_debug(f"Cache hit (memory): {path}", "get_cache")
                return data.get('value')
            
            log_debug(f"Cache expired (memory): {path}", "get_cache")
            home.clearProperty(path)
        except json.JSONDecodeError:
            home.clearProperty(path)
    
    # Try file cache
    filepath = os.path.join(cachepath, f"{path}.json")
    try:
        with open(filepath) as f: 
            data = json.load(f)

        expiry = data.get('sigValidUntil', 0)

        if expiry is False or expiry > current_time:
            value = data.get('value')
            home.setProperty(path, json.dumps({"sigValidUntil": expiry, "value": value}))
            log_debug(f"Cache hit (file): {path}", "get_cache")
            return value
        
        log_debug(f"Cache expired (file): {path}", "get_cache")
        os.remove(filepath)
    except (FileNotFoundError, json.JSONDecodeError, IOError):
        pass
    
    log_debug(f"Cache miss: {path}", "get_cache")
    return None

# =============================================================================
# PLUGIN FRAMEWORK UTILITIES
# =============================================================================

def _get_handle(): 
    """
    Get the plugin handle from command line arguments.
    """
    return int(sys.argv[1])


def end(succeeded=True, cacheToDisc=True): 
    """
    End the directory listing.
    """
    log_debug(f"Ending directory (succeeded={succeeded}, cacheToDisc={cacheToDisc})", "end")
    return xbmcplugin.endOfDirectory(_get_handle(), succeeded=succeeded, cacheToDisc=cacheToDisc)


def add(params, listitem, isFolder=False): 
    
    url = url_for(params)
    log_debug(f"Adding item: {url}, isFolder={isFolder}", "add")
    return xbmcplugin.addDirectoryItem(_get_handle(), url, listitem, isFolder)


def add_items(items):
    """
    Add multiple items to the directory listing at once (faster than individual adds).
    
    Args:
        items: list of (url_params_dict, listitem, isFolder) tuples
    """
    handle = _get_handle()
    entries = []
    for params, listitem, isFolder in items:
        url = url_for(params)
        entries.append((url, listitem, isFolder))
    log_debug(f"Batch adding {len(entries)} items", "add_items")
    return xbmcplugin.addDirectoryItems(handle, entries, len(entries))


def notify(message, heading="Info", icon=xbmcgui.NOTIFICATION_INFO):
    """
    Show a non-blocking notification toast.
    Uses Kodi's default display time (5000ms) for consistency.
    """
    xbmcgui.Dialog().notification(heading, message, icon)


def set_content(content_type): 
    """
    Set the content type for the directory.
    """
    log_debug(f"Setting content type: {content_type}", "set_content")
    xbmcplugin.setContent(_get_handle(), content_type)


def set_resolved(listitem): 
    """
    Set the resolved URL for playback.
    """
    log_debug("Setting resolved URL", "set_resolved")
    xbmcplugin.setResolvedUrl(_get_handle(), True, listitem)


def sort_method(): 
    """
    Add video title sort method to the directory.
    """  
    log_debug("Adding sort method: VIDEO_TITLE", "sort_method")
    xbmcplugin.addSortMethod(_get_handle(), xbmcplugin.SORT_METHOD_VIDEO_TITLE)


# =============================================================================
# URL BUILDING
# =============================================================================

def convertPluginParams(params):
    """Convert a parameters dictionary to URL-encoded string."""
    parts = [urlencode({k: str(v) if isinstance(v, int) else v}) 
             for k, v in params.items()]
    return '&'.join(parts)

def url_for(params):
    """
    Build a plugin URL from parameters.
    """
    return f"{sys.argv[0]}?{convertPluginParams(params)}"


# =============================================================================
# TV FAVORITES MANAGEMENT
# =============================================================================
# Favorites are stored as a JSON file in the addon profile directory.
# Each favorite is {"name": "ChannelName", "group": "GroupName", "nickname": "OptionalNick"}

_favorites_path = os.path.join(addonprofile, "tv_favorites.json")


def _load_favorites():
    """Load TV favorites from disk. Returns list of dicts."""
    try:
        if os.path.exists(_favorites_path):
            with open(_favorites_path, "r") as f:
                data = json.load(f)
            # Ensure it's a list of dicts (not old-style list of strings)
            if isinstance(data, list):
                return data
    except (json.JSONDecodeError, IOError, OSError) as e:
        log_debug(f"Error loading favorites: {e}", "_load_favorites")
    return []


def _save_favorites(favorites):
    """Save TV favorites to disk. Uses atomic write for crash safety."""
    temp_path = None
    try:
        fd, temp_path = tempfile.mkstemp(dir=addonprofile)
        with os.fdopen(fd, "w") as f:
            json.dump(favorites, f, indent=2)
        os.replace(temp_path, _favorites_path)
        log_debug(f"Saved {len(favorites)} favorites", "_save_favorites")
    except (IOError, OSError) as e:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
        log(f"Error saving favorites: {e}", "_save_favorites", force=True)


def get_favorites():
    """Get list of TV favorites."""
    return _load_favorites()


def get_favorite_names():
    """Get set of favorite channel names for quick lookup."""
    return {fav["name"] for fav in _load_favorites() if isinstance(fav, dict) and "name" in fav}


def add_favorite(name, group):
    """Add a channel to TV favorites."""
    favorites = _load_favorites()
    # Check if already exists
    for fav in favorites:
        if isinstance(fav, dict) and fav.get("name") == name:
            log_debug(f"Channel already in favorites: {name}", "add_favorite")
            return
    # Add with empty nickname by default
    favorites.append({"name": name, "group": group, "nickname": ""})
    _save_favorites(favorites)
    log_debug(f"Added to favorites: {name} (group={group})", "add_favorite")


def rename_favorite(name, new_nickname):
    """Rename a favorite (add/update nickname)."""
    favorites = _load_favorites()
    found = False
    for fav in favorites:
        if isinstance(fav, dict) and fav.get("name") == name:
            fav["nickname"] = new_nickname
            found = True
            break
    if found:
        _save_favorites(favorites)
        log_debug(f"Renamed favorite {name} to {new_nickname}", "rename_favorite")


def move_favorite(name, direction):
    """
    Move a favorite in the list.
    Direction: 'up', 'down', 'top', or 'bottom'
    """
    favorites = _load_favorites()
    # Find index of item
    idx = -1
    for i, fav in enumerate(favorites):
        if isinstance(fav, dict) and fav.get("name") == name:
            idx = i
            break
            
    if idx == -1:
        return

    moved = False
    if direction == "up" and idx > 0:
        favorites[idx], favorites[idx-1] = favorites[idx-1], favorites[idx]
        moved = True
    elif direction == "down" and idx < len(favorites) - 1:
        favorites[idx], favorites[idx+1] = favorites[idx+1], favorites[idx]
        moved = True
    elif direction == "top" and idx > 0:
        item = favorites.pop(idx)
        favorites.insert(0, item)
        moved = True
    elif direction == "bottom" and idx < len(favorites) - 1:
        item = favorites.pop(idx)
        favorites.append(item)
        moved = True

    if moved:
        _save_favorites(favorites)
        log_debug(f"Moved favorite {name} {direction.upper()}", "move_favorite")


def remove_favorite(name):
    """Remove a channel from TV favorites."""
    favorites = _load_favorites()
    favorites = [fav for fav in favorites if not (isinstance(fav, dict) and fav.get("name") == name)]
    _save_favorites(favorites)
    log_debug(f"Removed from favorites: {name}", "remove_favorite")


def clear_all_favorites():
    """Remove all TV favorites."""
    _save_favorites([])
    log_debug("All favorites cleared", "clear_all_favorites")


def is_favorite(name):
    """Check if a channel is in TV favorites."""
    return name in get_favorite_names()


def export_favorites():
    """
    Export TV favorites to a user-chosen location via file manager.
    Saves as VavooTV-Favorites-YYYY-MM-DD.json.
    """
    favorites = _load_favorites()
    if not favorites:
        xbmcgui.Dialog().ok("Favorites", "No favorites to export.")
        return

    # browse type 0 = GetDirectory - Kodi shows all sources incl. network (NAS, FTP, SMB)
    dest_folder = xbmcgui.Dialog().browse(0, "Select Export Location", "files")
    if not dest_folder:
        return

    date_str = datetime.now().strftime("%Y-%m-%d")
    filename = f"VavooTV-Favorites-{date_str}.json"
    # Use string concat to keep VFS protocol paths (smb://, ftp://) intact
    dest_path = dest_folder + filename

    try:
        content = json.dumps(favorites, indent=2)
        f = xbmcvfs.File(dest_path, "w")
        try:
            f.write(content)
        finally:
            f.close()
        log_debug(f"Exported {len(favorites)} favorites to {dest_path}", "export_favorites")
        xbmcgui.Dialog().ok(
            "Favorites",
            "Favorites successfully exported!\n"
            f"Path: {dest_path}"
        )
    except (IOError, OSError) as e:
        log(f"Error exporting favorites: {e}", "export_favorites", force=True)
        xbmcgui.Dialog().ok("Error", f"Export failed:\n{e}")


def import_favorites():
    """
    Import TV favorites from a user-chosen JSON file via file manager.
    Replaces current favorites with imported ones.
    """
    # browse type 1 = GetFile - picks a single file, supports network sources
    source_file = xbmcgui.Dialog().browse(1, "Select Favorites File", "files", ".json")
    if not source_file:
        return

    try:
        f = xbmcvfs.File(source_file, "r")
        try:
            content = f.read()
        finally:
            f.close()
        data = json.loads(content)

        # Validate structure: must be a list of dicts with at least "name"
        if not isinstance(data, list):
            xbmcgui.Dialog().ok("Error", "Invalid file format.\nExpected a list of favorites.")
            return

        for item in data:
            if not isinstance(item, dict) or "name" not in item or "group" not in item:
                xbmcgui.Dialog().ok("Error", "Invalid file format.\nEach entry must have 'name' and 'group' fields.")
                return

        _save_favorites(data)
        log_debug(f"Imported {len(data)} favorites from {source_file}", "import_favorites")
        xbmcgui.Dialog().ok(
            "Favorites",
            f"Favorites imported successfully!\n{len(data)} channels loaded."
        )
        xbmc.executebuiltin("Container.Refresh")

    except json.JSONDecodeError:
        xbmcgui.Dialog().ok("Error", "Invalid JSON file.\nPlease select a valid favorites file.")
    except (IOError, OSError) as e:
        log(f"Error importing favorites: {e}", "import_favorites", force=True)
        xbmcgui.Dialog().ok("Error", f"Import failed:\n{e}")
