# -*- coding: utf-8 -*-
"""
vjackson.py - Directory Navigation Module

This module handles the addon's navigation structure and directory listings:
- Main index (country/region selection)
- Category navigation
- Refresh handlers for countries and channels
- Helper functions for creating directory items

The module acts as a router for the addon's menu structure,
delegating to vjlive.py for actual channel listing and playback.
"""

import sys

import xbmc
import xbmcgui
from xbmcgui import ListItem
from urllib.parse import quote_plus

from resources.lib import utils
from resources.lib import vjlive

from infotagger.listitem import ListItemInfoTag


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def _set_listitem_info(listitem, info_labels):
    """
    Set info labels on a ListItem.
    """
    info_tag = ListItemInfoTag(listitem, 'video')
    info_tag.set_info(info_labels)


# =============================================================================
# NAVIGATION HANDLERS
# =============================================================================

def _index(params):
    """
    Display the main index with three specific options:
    1. Country List
    2. TV Favorites
    3. Settings
    """
    utils.set_content("files")
    
    # 1. Country List
    addDir2("Country List", "show_countries", isFolder=True)
    
    # 2. TV Favorites
    # Keep context menu for quick cleanup
    fav_ctx = [
        ("Make M3U", f"RunPlugin({sys.argv[0]}?action=makem3u&group=favorites)"),
        ("Import Favorites", f"RunPlugin({sys.argv[0]}?action=importFavorites)"),
        ("Export Favorites", f"RunPlugin({sys.argv[0]}?action=exportFavorites)"),
        ("Remove All Favorites", f"RunPlugin({sys.argv[0]}?action=delallTvFavorit)"),
        ("Settings", f"RunPlugin({sys.argv[0]}?action=settings)")
    ]
    addDir2("TV Favorites", "favchannels", context=fav_ctx, isFolder=True)
    
    # 3. Settings
    addDir2("Settings", "settings", isFolder=False)
    
    utils.end(cacheToDisc=False)


def _show_countries(params):
    """
    Display the list of available countries/regions.
    If the index is down, get_available_countries shows an error dialog
    and returns []. We then signal failure so Kodi goes back to main menu.
    """
    utils.set_content("files")
    
    countries = vjlive.get_available_countries()
    
    if not countries:
        # Index is down — error dialog was already shown.
        # Signal failed directory so Kodi navigates back to main menu.
        utils.end(succeeded=False)
        return
    
    # --- Red Refresh entry at top ---
    addDir2("[COLOR red]Refresh Country List[/COLOR]", "refresh_countries", isFolder=True)
    
    for country in countries:
        safe_country = quote_plus(country)
        
        cm = [
            ("Make M3U", f"RunPlugin({sys.argv[0]}?action=makem3u&group={safe_country})"),
            ("Settings", f"RunPlugin({sys.argv[0]}?action=settings)")
        ]
        
        addDir2(country, "channelsbycategory", 
                context=cm,
                group=country)
    
    utils.end(cacheToDisc=False)


def _refresh_countries(params):
    """
    Force-refresh the country list, show progress, and cleanly reload.
    Only triggers Container.Refresh on success to prevent nav-back on auth failure.
    """
    progress = xbmcgui.DialogProgress()
    progress.create('', 'Refreshing country list...')
    progress.update(30)
    
    vjlive.refresh_country_cache()
    
    progress.update(70, 'Fetching fresh list...')
    try:
        countries = vjlive.get_available_countries(use_cache=False)
        success = bool(countries)
    except Exception:
        success = False
    
    progress.update(100)
    progress.close()
    
    utils.end(succeeded=False)
    xbmc.executebuiltin("Action(ParentDir)")
    xbmc.sleep(300)
    
    if success:
        utils.notify("Country list refreshed")
        xbmc.executebuiltin("Container.Refresh")
    else:
        utils.notify("Refresh failed - please try again", icon=xbmcgui.NOTIFICATION_ERROR)


def _refresh_channels(params):
    """
    Force-refresh the channel list for a specific group, show progress, and reload.
    Only triggers Container.Refresh on success to prevent nav-back on auth failure.
    """
    group = params.get("group", "Germany")
    
    progress = xbmcgui.DialogProgress()
    progress.create('', f'Refreshing channels for {group}...')
    progress.update(30)
    
    vjlive.refresh_group_cache(group)
    
    progress.update(70, 'Fetching fresh list...')
    try:
        channels = vjlive.getchannels_by_group(group)
        success = bool(channels)
    except Exception:
        success = False
    
    progress.update(100)
    progress.close()
    
    utils.end(succeeded=False)
    xbmc.executebuiltin("Action(ParentDir)")
    xbmc.sleep(300)
    
    if success:
        utils.notify(f"{group} channels refreshed")
        xbmc.executebuiltin("Container.Refresh")
    else:
        utils.notify("Refresh failed - please try again", icon=xbmcgui.NOTIFICATION_ERROR)


# =============================================================================
# DIRECTORY ITEM CREATION
# =============================================================================

def addDir(name, params, isFolder=True, context=None):
    """
    Add a directory item to the current listing.
    Uses Kodi's default folder icon.
    """
    listitem = ListItem(name)
    
    # Work on a copy so we don't mutate the caller's list
    context = list(context) if context else []
    
    if not context:
        context.append(("Settings", f"RunPlugin({sys.argv[0]}?action=settings)"))
    
    listitem.addContextMenuItems(context)
    
    info_labels = {"title": name, "plot": " "}
    _set_listitem_info(listitem, info_labels)
    
    utils.add(params, listitem, isFolder)


def addDir2(name, action, context=None, isFolder=True, **params):
    """
    Convenience wrapper for addDir with automatic action parameter.
    
    Example:
        addDir2("Germany", "channelsbycategory", group="Germany")
    """
    params["action"] = action
    addDir(name, params, isFolder, context or [])