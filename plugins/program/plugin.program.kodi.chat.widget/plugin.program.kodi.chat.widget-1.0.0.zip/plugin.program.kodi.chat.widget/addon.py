#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# plugin.program.kodi.chat.widget v1.0.0 – PlayForFun
# Widget-Provider: zeigt letzte Chat-Nachrichten als Homescreen-Widget

import sys
import os
import json
import hashlib
import urllib.request
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

API_URL   = 'https://rolling-playforfun.dynv6.net/kodi/index.php'
ADDON     = xbmcaddon.Addon()
ADDON_ID  = ADDON.getAddonInfo('id')
ICON      = ADDON.getAddonInfo('icon')
ADDON_PATH = ADDON.getAddonInfo('path')
WHITE_PNG  = os.path.join(ADDON_PATH, 'resources', 'media', 'white.png')


def fetch_messages(limit=10):
    try:
        req = urllib.request.Request(
            API_URL + '?action=read',
            headers={'User-Agent': 'KodiChatWidget/1.0'}
        )
        with urllib.request.urlopen(req, timeout=8) as r:
            msgs = json.loads(r.read().decode('utf-8'))
            return msgs[:limit] if msgs else []
    except Exception as e:
        xbmc.log(f'[KodiChatWidget] fetch error: {e}', xbmc.LOGERROR)
        return []


def make_thumb(name_s, text, ts):
    """Generiert ein 320x180 Thumbnail mit Name + Nachrichtentext."""
    thumb_dir = xbmcvfs.translatePath(
        os.path.join(ADDON.getAddonInfo('profile'), 'thumbs'))
    os.makedirs(thumb_dir, exist_ok=True)

    key  = hashlib.md5(f'{name_s}{text}{ts}'.encode()).hexdigest()
    path = os.path.join(thumb_dir, f'{key}.png')
    if os.path.exists(path):
        return path

    try:
        from PIL import Image, ImageDraw, ImageFont

        img  = Image.new('RGB', (320, 180), color=(10, 10, 22))
        draw = ImageDraw.Draw(img)

        # Farbiger Balken oben
        draw.rectangle([0, 0, 320, 5], fill=(0, 90, 136))

        # Fonts laden
        try:
            fn = '/system/fonts/DroidSans-Bold.ttf'
            ft = '/system/fonts/DroidSans.ttf'
            font_name = ImageFont.truetype(fn, 20)
            font_text = ImageFont.truetype(ft, 16)
            font_time = ImageFont.truetype(ft, 13)
        except Exception:
            font_name = ImageFont.load_default()
            font_text = font_name
            font_time = font_name

        # Name (cyan) + Uhrzeit (grau)
        draw.text((14, 14), name_s, fill=(0, 212, 255), font=font_name)
        draw.text((14, 42), ts,     fill=(60, 100, 140), font=font_time)

        # Nachricht mit Zeilenumbruch
        words, lines, cur = text.split(), [], ''
        for w in words:
            test = (cur + ' ' + w).strip()
            if draw.textbbox((0,0), test, font=font_text)[2] > 292 and cur:
                lines.append(cur)
                cur = w
            else:
                cur = test
        if cur:
            lines.append(cur)

        y = 68
        for line in lines[:4]:
            draw.text((14, y), line, fill=(220, 220, 220), font=font_text)
            y += 24

        img.save(path, 'PNG')
        return path
    except Exception as e:
        xbmc.log(f'[KodiChatWidget] thumb error: {e}', xbmc.LOGWARNING)
        return ICON


def run():
    handle = int(sys.argv[1])
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))

    mode = params.get('mode', 'widget')

    # Klick auf Widget-Eintrag → Chat-Addon öffnen
    if mode == 'open':
        xbmc.executebuiltin('RunAddOn(script.kodi.chat)')
        return

    # Widget-Modus: Nachrichten laden und als Items ausgeben
    msgs = fetch_messages(10)

    if not msgs:
        item = xbmcgui.ListItem(label='Kodi Chat – Keine Nachrichten', offscreen=True)
        item.setArt({'icon': ICON, 'thumb': ICON})
        item.setIsFolder(False)
        xbmcplugin.addDirectoryItem(handle, '', item, False)
    else:
        for m in msgs:
            name_s = m.get('name', '?')
            text   = m.get('message', '')
            ts     = m.get('time', '')
            thumb  = make_thumb(name_s, text, ts)

            item = xbmcgui.ListItem(
                label     = f'{name_s}:  {text}',
                label2    = ts,
                offscreen = True
            )
            item.setIsFolder(False)
            item.setArt({
                'icon':   thumb,
                'thumb':  thumb,
                'poster': thumb,
                'banner': thumb,
            })
            item.setInfo('video', {
                'title':  f'{name_s}: {text}',
                'plot':   text,
                'studio': name_s,
            })
            # Klick → Chat öffnen
            xbmcplugin.addDirectoryItem(
                handle,
                f'plugin://{ADDON_ID}/?mode=open',
                item, False
            )

    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(
        handle, succeeded=True, updateListing=False, cacheToDisc=False)


if __name__ == '__main__':
    run()
