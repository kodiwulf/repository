import xbmcaddon
import xbmcvfs
from pathlib import Path

ADDON_ID = 'plugin.program.lazymaintenance'
ADDON = xbmcaddon.Addon(ADDON_ID)

# Helper for Kodi Paths using pathlib
def get_kodi_path(path_str):
    return Path(xbmcvfs.translatePath(path_str))

# Paths
HOME = get_kodi_path('special://home/')
ADDONS = get_kodi_path('special://home/addons/')
USERDATA = get_kodi_path('special://userdata/')
TEMP = get_kodi_path('special://temp/')
THUMBNAILS = get_kodi_path('special://thumbnails/')
PACKAGES = get_kodi_path('special://home/addons/packages/')
ADDONS_TEMP = get_kodi_path('special://home/addons/temp/')
LOGPATH = get_kodi_path('special://logpath/')
MEDIA = get_kodi_path('special://home/media/')
DATABASE = get_kodi_path('special://userdata/Database/')
