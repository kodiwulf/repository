import xbmc
import xbmcaddon

ADDON_ID = 'plugin.program.lazymaintenance'

monitor = xbmc.Monitor()

# Initial settle - give Kodi a moment to start its boot operations
if not monitor.waitForAbort(5):
    try:
        settings = xbmcaddon.Addon(ADDON_ID)
        if settings.getSetting('auto_clean_enabled') == 'true':

            # Wait until Kodi is idle (no addon updates, no library scans).
            # Hard cap at 60s so a stuck scan never blocks auto clean indefinitely.
            HARD_CAP = 60
            POLL_INTERVAL = 1
            wait_total = 0
            aborted = False

            while wait_total < HARD_CAP:
                busy = (xbmc.getCondVisibility('Library.IsScanning') or
                        xbmc.getCondVisibility('System.HasAddonUpdates'))
                if not busy:
                    xbmc.log(f"{ADDON_ID}: Kodi idle after {wait_total}s, starting auto clean.", xbmc.LOGINFO)
                    break
                if monitor.waitForAbort(POLL_INTERVAL):
                    aborted = True
                    break
                wait_total += POLL_INTERVAL
            else:
                xbmc.log(f"{ADDON_ID}: Hard cap {HARD_CAP}s reached, proceeding anyway.", xbmc.LOGWARNING)

            if not aborted:
                import addon
                addon.clean()
                xbmc.log(f"{ADDON_ID}: Auto clean finished.", xbmc.LOGINFO)
        else:
            xbmc.log(f"{ADDON_ID}: Auto clean disabled in settings.", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"{ADDON_ID}: Auto clean failed: {e}", xbmc.LOGERROR)
