import sys
import xbmc
import xbmcplugin
from .params import Params
from .menus import main_menu, build_menu
from .build_install import build_install
from .addonvar import addon, UPDATE_VERSION, CURRENT_BUILD, BUILD_URL

try:
    HANDLE = int(sys.argv[1])
except IndexError:
    HANDLE = 0

def router(paramstring):
    p = Params(paramstring)
    xbmc.log(str(p.get_params()), xbmc.LOGDEBUG)
    
    name = p.get_name()
    name2 = p.get_name2()
    version = p.get_version()
    url = p.get_url()
    mode = p.get_mode()
    icon = p.get_icon()
    description = p.get_description()
    
    xbmcplugin.setContent(HANDLE, 'files')

    if mode is None:
        main_menu()
    
    elif mode == 1:
        build_menu()
    
    elif mode == 3:
        build_install(name, name2, version, url)
    
    elif mode == 9:
        addon.openSettings()

    elif mode == 31:
        name = CURRENT_BUILD
        name2 = name
        if BUILD_URL.startswith('https://www.dropbox.com'):
           url = BUILD_URL.replace('dl=0', 'dl=1')
        else:
            url = BUILD_URL
        build_install(name, name2, UPDATE_VERSION, url) 
        
    xbmcplugin.endOfDirectory(HANDLE)
