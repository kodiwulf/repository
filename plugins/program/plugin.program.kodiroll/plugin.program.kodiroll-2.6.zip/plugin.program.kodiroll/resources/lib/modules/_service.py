import xbmc
import xbmcgui
from .maintenance import clear_packages_startup
from .addonvar import setting, setting_set, addon_name, dialog, local_string, addon_id, gui_save_default, UPDATE_VERSION, CURRENT_BUILD, CURRENT_VERSION, BUILD_URL
from .build_install import restore_binary, binaries_path, build_install
from .addons_enable import enable_addons
from .save_data import backup_gui_skin

class Startup:
    def check_updates(self):
           if CURRENT_BUILD == 'Kein Build installiert':
               nobuild = dialog.yesnocustom(
                   addon_name,
                   'Es ist aktuell kein Build installiert.\nMöchtest du jetzt eins installieren?',
                   'Später erinnern'
               )
               if nobuild == 1:
                   xbmc.executebuiltin(
                       f'ActivateWindow(10001, "plugin://{addon_id}/?mode=1",return)'
                   )
               elif nobuild == 0:
                   setting_set('buildname', 'Kein Build')
               return
           if UPDATE_VERSION is None:
               pass
           else:
               if UPDATE_VERSION > CURRENT_VERSION and setting('update_passed') != 'true':
                   update_available = xbmcgui.Dialog().yesno(
                       addon_name,
                       f'{local_string(30047)} {CURRENT_BUILD} {local_string(30048)}\n{local_string(30049)} {CURRENT_VERSION}\n{local_string(30050)} {UPDATE_VERSION}\n{local_string(30051)}',
                       yeslabel='Jetzt updaten', nolabel='Nicht jetzt'
                   )
                   
                   if update_available:
                       name = CURRENT_BUILD
                       name2 = name
                       if BUILD_URL.startswith('https://www.dropbox.com'):
                           url = BUILD_URL.replace('dl=0', 'dl=1')
                       else:
                           url = BUILD_URL
                       build_install(name, name2, UPDATE_VERSION, url) 
                       
                   else:
                       remind_later = xbmcgui.Dialog().yesno(addon_name, 'Möchtest du später nochmal erinnert werden?', yeslabel='Später erinnern', nolabel='Ignorieren', defaultbutton=xbmcgui.DLG_YESNO_YES_BTN)
                       if remind_later:
                           setting_set('update_passed', 'false')
                       else:
                           setting_set('update_passed', 'true')
                       
               elif UPDATE_VERSION == CURRENT_VERSION and setting('update_passed') == 'true':
                   setting_set('update_passed', 'false')
                   
    def save_menu(self):
        choices = []
        preselect = []
        if setting('savedata') == 'true':
            choices.append('[I]Trakt & Debrid Daten[/I][TABS]5[/TABS][Preselected]')
            preselect.append(0)
        else:
            choices.append('Trakt & Debrid Daten')
        if setting('saveyoutube') == 'true':
            choices.append('[I]YouTube API Keys[/I][TABS]5[/TABS][Preselected]')
            preselect.append(1)
        else:
            choices.append('YouTube API Keys')
        if setting('saveadvanced') == 'true':
            choices.append('[I]Erweiterte Einstellungen[/I][TABS]5[/TABS][Preselected]')
            preselect.append(2)
        else:
            choices.append('Erweiterte Einstellungen')
        if setting('savegui') == 'true':
            choices.append('[I]GUI Einstellungen[/I][TABS]6[/TABS][Preselected]')
            preselect.append(3)
        else:
            choices.append('GUI Einstellungen')
        if setting('savefavs') == 'true':
            choices.append('[I]Favoriten[/I][TABS]7[/TABS][Preselected]')
            preselect.append(4)
        else:
            choices.append('Favoriten')
        if setting('savesources') == 'true':
            choices.append('[I]Quellen[/I][TABS]7[/TABS][Preselected]')
            preselect.append(5)
        else:
            choices.append('Quellen')
        save_select = dialog.multiselect(
            f'{addon_name} - {local_string(30052)}',
            choices,
            preselect=preselect
        )
        # Select Save Items
        if save_select is None:
            return
        save_items = [choices[index] for index in save_select]
                
        if 'Trakt & Debrid Daten' in save_items:
            setting_set('savedata', 'true')
        elif '[I]Trakt & Debrid Daten[/I][TABS]5[/TABS][Preselected]' in save_items:
            setting_set('savedata', 'true')
        else:
            setting_set('savedata', 'false')
            
        if 'YouTube API Keys' in save_items:
            setting_set('saveyoutube', 'true')
        elif '[I]YouTube API Keys[/I][TABS]5[/TABS][Preselected]' in save_items:
            setting_set('saveyoutube', 'true')
        else:
            setting_set('saveyoutube', 'false')

        if 'Erweiterte Einstellungen' in save_items:
            setting_set('saveadvanced', 'true')
        elif '[I]Erweiterte Einstellungen[/I][TABS]5[/TABS][Preselected]' in save_items:
            setting_set('saveadvanced', 'true')
        else:
            setting_set('saveadvanced', 'false')

        if 'GUI Einstellungen' in save_items:
            setting_set('savegui', 'true')
        elif '[I]GUI Einstellungen[/I][TABS]6[/TABS][Preselected]' in save_items:
            setting_set('savegui', 'true')
        else:
            setting_set('savegui', 'false')
            
        if 'Favoriten' in save_items:
            setting_set('savefavs', 'true')
        elif '[I]Favoriten[/I][TABS]7[/TABS][Preselected]' in save_items:
            setting_set('savefavs', 'true')
        else:
            setting_set('savefavs', 'false')
            
        if 'Quellen' in save_items:
            setting_set('savesources', 'true')
        elif '[I]Quellen[/I][TABS]7[/TABS][Preselected]' in save_items:
            setting_set('savesources', 'true')
        else:
            setting_set('savesources', 'false')
  
        setting_set('firstrunSave', 'true')

    def run_startup(self):
        if setting('firstrunSave') != 'true':
            self.save_menu()
            xbmc.sleep(2000)
        if setting('firstrun') == 'true':
            enable_addons()
            backup_gui_skin(gui_save_default)
            setting_set('firstrun', 'false')
        else:
            if setting('autoclearpackages') == 'true':
                clear_packages_startup()
            xbmc.sleep(3000)  # Delay Build Update Notification
            self.check_updates()
        if binaries_path.exists():
            restore_binary()
