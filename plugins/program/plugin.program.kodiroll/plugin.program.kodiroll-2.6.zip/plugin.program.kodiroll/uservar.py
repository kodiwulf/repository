'''#####-----Build File-----#####'''
buildfile = 'http://rolling-playforfun.dynv6.net/downloads/builds.xml'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
